﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace FileListEditor
{
    /// <summary>
    /// Updates the FileList.xml.
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {
            string xmlFile = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + "\\XPero\\Vize\\FileList.xml";

            if (File.Exists(xmlFile))
            {
                if (args[0] == "-add")
                {
                    if (args.Length == 7)
                    {
                        Functions.AddFile(args, xmlFile);
                    }
                }
                else if (args[0] == "-remove")
                {
                    if (args.Length == 2)
                    {
                        Functions.RemoveFile(args, xmlFile);
                    }
                }
            }
        }
    }

    /// <summary>
    /// Functions to update the FileList.xml.
    /// </summary>
    public static class Functions
    {
        /// <summary>
        /// Adds a file to the FileList.xml.
        /// </summary>
        /// <param name="args">The information of the file.</param>
        /// <param name="xmlFile">The XML file to edit.</param>
        public static void AddFile(string[] args, string xmlFile)
        {
            // args[0] = -add
            // args[1] = file
            // args[2] = path
            // args[3] = type
            // args[4] = filesize
            // args[5] = patched
            // args[6] = shipswithwindows

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFile);

            XmlElement elmRoot = xmlDoc.DocumentElement;

            XmlElement elmNew = xmlDoc.CreateElement("file");
            XmlAttribute attPath = xmlDoc.CreateAttribute("path");
            XmlAttribute attType = xmlDoc.CreateAttribute("type");
            XmlAttribute attFileSize = xmlDoc.CreateAttribute("filesize");
            XmlAttribute attPatched = xmlDoc.CreateAttribute("patched");
            XmlAttribute attShipsWithWindows = xmlDoc.CreateAttribute("shipswithwindows");

            XmlText file = xmlDoc.CreateTextNode(args[1]);

            elmRoot.AppendChild(elmNew);
            elmRoot.LastChild.Attributes.Append(attPath);
            elmRoot.LastChild.Attributes.Append(attType);
            elmRoot.LastChild.Attributes.Append(attFileSize);
            elmRoot.LastChild.Attributes.Append(attPatched);
            elmRoot.LastChild.Attributes.Append(attShipsWithWindows);

            elmRoot.LastChild.Attributes["path"].InnerText = args[2];
            elmRoot.LastChild.Attributes["type"].InnerText = args[3];
            elmRoot.LastChild.Attributes["filesize"].InnerText = args[4];
            elmRoot.LastChild.Attributes["patched"].InnerText = args[5];
            elmRoot.LastChild.Attributes["shipswithwindows"].InnerText = args[6];
            elmRoot.LastChild.AppendChild(file);

            xmlDoc.Save(xmlFile);
        }
        /// <summary>
        /// Removes a file from the FileList.xml.
        /// </summary>
        /// <param name="args">The information of the file.</param>
        /// <param name="xmlFile">The XML file to edit.</param>
        public static void RemoveFile(string[] args, string xmlFile)
        {
            // args[0] = -remove
            // args[1] = file

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFile);

            XmlNodeList fileList = xmlDoc.GetElementsByTagName("file");

            XmlElement elmRoot = xmlDoc.DocumentElement;



            foreach (XmlNode node in fileList)
            {
                if (node.InnerText == args[1])
                {
                    elmRoot.RemoveChild(node);
                    xmlDoc.Save(xmlFile);
                    return;
                }
            }
        }
    }
}
