﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;
using Shell32;

namespace Vize
{
    /// <summary>
    /// Returns the detailed information of a given file.
    /// </summary>
    public class GetFileInfo
    {
        private string fileDescription = String.Empty;

        /// <summary>
        /// Gets file information.
        /// </summary>
        /// <param name="filePath">The file to process.</param>
        public GetFileInfo(string filePath)
        {
            // check if the given File exists
            if (File.Exists(filePath))
            {
                string detailedInfo = string.Empty;
                FileInfo oFInfo = new FileInfo(filePath);
                fileDescription = GetDetailedFileInfo(filePath);
            }
            else
            {
                throw new Exception("The given File does not exist");
            }

        }
        /// <summary>
        /// The file description.
        /// </summary>
        public string FileDescription
        {
            get { return fileDescription; }
        }

        private string GetDetailedFileInfo(string file)
        {
            string description = string.Empty;

            if (file.Length > 0)
            {
                try
                {
                    // Creating a ShellClass Object from the Shell32.
                    ShellClass sh = new ShellClass();
                    // Creating a Folder Object from Folder that inculdes the File.
                    Folder dir = sh.NameSpace(Path.GetDirectoryName(file));
                    // Creating a new FolderItem from Folder that includes the File.
                    FolderItem item = dir.ParseName(Path.GetFileName(file));
                    // 34 == File description.
                    description = dir.GetDetailsOf(item, 34);
                }
                catch
                {
                    description = "Error retrieving file information.";
                }
            }
            return description;
        }
    }
}
