﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Vize.VistaControls;

namespace Vize.Pages
{
    public partial class PageHome : UserControl
    {
        public PageHome()
        {
            InitializeComponent();
        }

        public Label LabelTitleHome
        {
            get
            {
                return this.lblTitleHome;
            }
            set
            {
                this.lblTitleHome = value;
            }
        }

        public Label LabelDescHome
        {
            get
            {
                return this.lblDescHome;
            }
            set
            {
                this.lblDescHome = value;
            }
        }

        public Label LabelChooseOption
        {
            get
            {
                return this.lblChooseOption;
            }
            set
            {
                this.lblChooseOption = value;
            }
        }

        public Panel PanelHome
        {
            get
            {
                return this.panel1;
            }
            set
            {
                this.panel1 = value;
            }
        }

        public CommandLink ButtonPatchPage
        {
            get
            {
                return this.btnPatchPage;
            }
            set
            {
                this.btnPatchPage = value;
            }

        }

        public CommandLink ButtonReloadPage
        {
            get
            {
                return this.btnReloaderPage;
            }
            set
            {
                this.btnReloaderPage = value;
            }

        }

        public CommandLink ButtonRestorePage
        {
            get
            {
                return this.btnRestorePage;
            }
            set
            {
                this.btnRestorePage = value;
            }

        }
    }
}
