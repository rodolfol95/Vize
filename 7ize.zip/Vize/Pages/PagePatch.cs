﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Vize.Pages
{
    public partial class PagePatch : UserControl
    {
        public PagePatch()
        {
            InitializeComponent();
        }

        public VistaControls.ComboBox ComboPatchSelectFiles
        {
            get
            {
                return this.cmbSelect;
            }
            set
            {
                this.cmbSelect = value;
            }

        }

        public VistaControls.ListView ListPatchFiles
        {
            get
            {
                return this.lstPatchFiles;
            }
            set
            {
                this.lstPatchFiles = value;
            }

        }

        public VistaControls.ProgressBar ProgressBarPatcher
        {
            get
            {
                return this.progressBarPatcher;
            }
            set
            {
                this.progressBarPatcher = value;
            }

        }

        public VistaControls.Button ButtonPatch
        {
            get
            {
                return this.btnPatch;
            }
            set
            {
                this.btnPatch = value;
            }

        }

        public Label LabelStatusPatch
        {
            get
            {
                return this.lblStatusPatcher;
            }
            set
            {
                this.lblStatusPatcher = value;
            }

        }

        public LinkLabel LabelSeeErrors
        {
            get
            {
                return this.linkSeeErrorsPatcher;
            }
            set
            {
                this.linkSeeErrorsPatcher = value;
            }

        }

        public PictureBox PicInfoPatcher
        {
            get
            {
                return this.picInfoPatcher;
            }
            set
            {
                this.picInfoPatcher = value;
            }
        }

        public Label LabelTitlePatcher
        {
            get
            {
                return this.lblTitlePatcher;
            }
            set
            {
                this.lblTitlePatcher = value;
            }

        }

        public Label LabelDescPatcher
        {
            get
            {
                return this.lblDescPatcher;
            }
            set
            {
                this.lblDescPatcher = value;
            }

        }
    }
}
