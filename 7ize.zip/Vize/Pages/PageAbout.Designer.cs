﻿namespace Vize.Pages
{
    partial class PageAbout
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTranslationAuthor = new System.Windows.Forms.Label();
            this.lblTranslation = new System.Windows.Forms.Label();
            this.lblCopyRight = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnVisitHomepage = new Vize.VistaControls.CommandLink();
            this.lblDescAbout3 = new System.Windows.Forms.Label();
            this.lblDescAbout2 = new System.Windows.Forms.Label();
            this.lblDescAbout1 = new System.Windows.Forms.Label();
            this.lblTitleAbout = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lblTranslationAuthor);
            this.panel1.Controls.Add(this.lblTranslation);
            this.panel1.Controls.Add(this.lblCopyRight);
            this.panel1.Controls.Add(this.lblVersion);
            this.panel1.Controls.Add(this.btnVisitHomepage);
            this.panel1.Controls.Add(this.lblDescAbout3);
            this.panel1.Controls.Add(this.lblDescAbout2);
            this.panel1.Controls.Add(this.lblDescAbout1);
            this.panel1.Controls.Add(this.lblTitleAbout);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 440);
            this.panel1.TabIndex = 3;
            // 
            // lblTranslationAuthor
            // 
            this.lblTranslationAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTranslationAuthor.AutoSize = true;
            this.lblTranslationAuthor.BackColor = System.Drawing.Color.Transparent;
            this.lblTranslationAuthor.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTranslationAuthor.Location = new System.Drawing.Point(4, 418);
            this.lblTranslationAuthor.Name = "lblTranslationAuthor";
            this.lblTranslationAuthor.Size = new System.Drawing.Size(58, 13);
            this.lblTranslationAuthor.TabIndex = 9;
            this.lblTranslationAuthor.Text = "Translator";
            // 
            // lblTranslation
            // 
            this.lblTranslation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTranslation.AutoSize = true;
            this.lblTranslation.Location = new System.Drawing.Point(3, 399);
            this.lblTranslation.Name = "lblTranslation";
            this.lblTranslation.Size = new System.Drawing.Size(67, 13);
            this.lblTranslation.TabIndex = 8;
            this.lblTranslation.Text = "Translation:";
            // 
            // lblCopyRight
            // 
            this.lblCopyRight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCopyRight.AutoSize = true;
            this.lblCopyRight.BackColor = System.Drawing.Color.Transparent;
            this.lblCopyRight.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCopyRight.Location = new System.Drawing.Point(417, 418);
            this.lblCopyRight.Name = "lblCopyRight";
            this.lblCopyRight.Size = new System.Drawing.Size(76, 13);
            this.lblCopyRight.TabIndex = 6;
            this.lblCopyRight.Text = "© 2009 VMax";
            this.lblCopyRight.Click += new System.EventHandler(this.lblCopyRight_Click);
            // 
            // lblVersion
            // 
            this.lblVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(403, 399);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(90, 13);
            this.lblVersion.TabIndex = 7;
            this.lblVersion.Text = "Version 0.7 Beta";
            // 
            // btnVisitHomepage
            // 
            this.btnVisitHomepage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVisitHomepage.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnVisitHomepage.Location = new System.Drawing.Point(0, 207);
            this.btnVisitHomepage.Margin = new System.Windows.Forms.Padding(3, 8, 3, 8);
            this.btnVisitHomepage.Name = "btnVisitHomepage";
            this.btnVisitHomepage.Note = "Learn more about Vize and other projects by XPero.";
            this.btnVisitHomepage.Size = new System.Drawing.Size(480, 73);
            this.btnVisitHomepage.TabIndex = 5;
            this.btnVisitHomepage.Text = "Visit Vize\'s Website";
            this.btnVisitHomepage.UseVisualStyleBackColor = true;
            // 
            // lblDescAbout3
            // 
            this.lblDescAbout3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescAbout3.Location = new System.Drawing.Point(4, 116);
            this.lblDescAbout3.Name = "lblDescAbout3";
            this.lblDescAbout3.Size = new System.Drawing.Size(480, 46);
            this.lblDescAbout3.TabIndex = 3;
            // 
            // lblDescAbout2
            // 
            this.lblDescAbout2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescAbout2.Location = new System.Drawing.Point(4, 78);
            this.lblDescAbout2.Name = "lblDescAbout2";
            this.lblDescAbout2.Size = new System.Drawing.Size(480, 38);
            this.lblDescAbout2.TabIndex = 2;
            this.lblDescAbout2.Text = "Vize automates the process of replacing resources in system files, applying the r" +
                "eal fit and finish to Windows Vista.";
            // 
            // lblDescAbout1
            // 
            this.lblDescAbout1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescAbout1.Location = new System.Drawing.Point(4, 40);
            this.lblDescAbout1.Name = "lblDescAbout1";
            this.lblDescAbout1.Size = new System.Drawing.Size(480, 38);
            this.lblDescAbout1.TabIndex = 1;
            this.lblDescAbout1.Text = "Vize is a GUI enhancer for Windows Vista. It replaces most of the non-Vista icons" +
                ", animations and bitmaps that Microsoft is still overlooking.";
            // 
            // lblTitleAbout
            // 
            this.lblTitleAbout.AutoSize = true;
            this.lblTitleAbout.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTitleAbout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.lblTitleAbout.Location = new System.Drawing.Point(3, 3);
            this.lblTitleAbout.Name = "lblTitleAbout";
            this.lblTitleAbout.Size = new System.Drawing.Size(85, 21);
            this.lblTitleAbout.TabIndex = 0;
            this.lblTitleAbout.Text = "About Vize";
            // 
            // PageAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Name = "PageAbout";
            this.Size = new System.Drawing.Size(500, 440);
            this.Load += new System.EventHandler(this.PageAbout_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDescAbout1;
        private System.Windows.Forms.Label lblTitleAbout;
        private System.Windows.Forms.Label lblDescAbout2;
        private System.Windows.Forms.Label lblDescAbout3;
        private VistaControls.CommandLink btnVisitHomepage;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label lblCopyRight;
        private System.Windows.Forms.Label lblTranslation;
        private System.Windows.Forms.Label lblTranslationAuthor;
    }
}
