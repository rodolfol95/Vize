﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Diagnostics;

namespace PatcherHelper
{
    /// <summary>
    /// Functions to patch system files.
    /// </summary>
    public static class PatcherFunctions
    {
        // MoveFileEx API.
        const int MOVEFILE_REPLACE_EXISTING = 1;
        const int MOVEFILE_COPY_ALLOWED = 2;
        const int MOVEFILE_DELAY_UNTIL_REBOOT = 4;
        const int MOVEFILE_WRITE_THROUGH = 8;
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static extern bool MoveFileEx(string lpExistingFileName, string lpNewFileName, int dwFlags);
        /// <summary>
        /// Takes ownership of system files.
        /// </summary>
        /// <param name="fileName">The file to process.</param>
        /// <returns>Successful operation.</returns>
        public static bool TakeOwnership(string fileName)
        {
            Process takeOwnProcess = new Process();
            ProcessStartInfo takeOwnStartInfo = new ProcessStartInfo();

            takeOwnStartInfo.FileName = "takeown.exe";

            // Do not write error output to standard stream.
            takeOwnStartInfo.RedirectStandardError = false;
            // Do not write output to Process.StandardOutput Stream.
            takeOwnStartInfo.RedirectStandardOutput = false;
            // Do not read input from Process.StandardInput (i/e; the keyboard).
            takeOwnStartInfo.RedirectStandardInput = false;

            takeOwnStartInfo.UseShellExecute = false;
            // Do not show a command window.
            takeOwnStartInfo.CreateNoWindow = true;

            takeOwnStartInfo.Arguments = "/f " + fileName + " /a";

            takeOwnProcess.EnableRaisingEvents = true;
            takeOwnProcess.StartInfo = takeOwnStartInfo;

            // Start the process.
            takeOwnProcess.Start();

            // Wait for the process to exit.
            takeOwnProcess.WaitForExit();

            int exitCode = takeOwnProcess.ExitCode;
            bool takeOwnSuccessful = true;

            // Now we need to see if the process was successful.
            if (exitCode > 0 & !takeOwnProcess.HasExited)
            {
                takeOwnProcess.Kill();
                takeOwnSuccessful = false;
            }

            // Now clean up after ourselves.
            takeOwnProcess.Dispose();
            takeOwnStartInfo = null;
            return takeOwnSuccessful;
        }
        /// <summary>
        /// Grants full control to the file.
        /// </summary>
        /// <param name="fileName">The file to process.</param>
        /// <param name="userName">The user name to grant full control.</param>
        /// <returns>Sucessful operation.</returns>
        public static bool GrantFullControl(string fileName, string userName)
        {
            Process grantFullControlProcess = new Process();
            ProcessStartInfo grantFullControlStartInfo = new ProcessStartInfo();

            grantFullControlStartInfo.FileName = "icacls.exe";

            // Do not write error output to standard stream.
            grantFullControlStartInfo.RedirectStandardError = false;
            // Do not write output to Process.StandardOutput Stream.
            grantFullControlStartInfo.RedirectStandardOutput = false;
            // Do not read input from Process.StandardInput (i/e; the keyboard).
            grantFullControlStartInfo.RedirectStandardInput = false;

            grantFullControlStartInfo.UseShellExecute = false;
            // Do not show a command window.
            grantFullControlStartInfo.CreateNoWindow = true;

            grantFullControlStartInfo.Arguments = fileName + " /grant " + userName + ":(F)";

            grantFullControlProcess.EnableRaisingEvents = true;
            grantFullControlProcess.StartInfo = grantFullControlStartInfo;

            // Start the process.
            grantFullControlProcess.Start();

            // Wait for the process to finish.
            grantFullControlProcess.WaitForExit();

            int exitCode = grantFullControlProcess.ExitCode;
            bool grantFullControlSuccessful = true;

            // Now we need to see if the process was successful.
            if (exitCode > 0 & !grantFullControlProcess.HasExited)
            {
                grantFullControlProcess.Kill();
                grantFullControlSuccessful = false;
            }

            // Now clean up after ourselves.
            grantFullControlProcess.Dispose();
            grantFullControlStartInfo = null;
            return grantFullControlSuccessful;
        }
        /// <summary>
        /// Resets edited permissions.
        /// </summary>
        /// <param name="fileName">The file to process.</param>
        /// <returns>Successful operation.</returns>
        public static bool ResetPermissions(string fileName)
        {
            Process resetPermissionsProcess = new Process();
            ProcessStartInfo resetPermissionsStartInfo = new ProcessStartInfo();

            resetPermissionsStartInfo.FileName = "icacls.exe";

            // Do not write error output to standard stream.
            resetPermissionsStartInfo.RedirectStandardError = false;
            // Do not write output to Process.StandardOutput Stream.
            resetPermissionsStartInfo.RedirectStandardOutput = false;
            // Do not read input from Process.StandardInput (i/e; the keyboard).
            resetPermissionsStartInfo.RedirectStandardInput = false;

            resetPermissionsStartInfo.UseShellExecute = false;
            // Do not show a command window.
            resetPermissionsStartInfo.CreateNoWindow = true;

            resetPermissionsStartInfo.Arguments = fileName + " /reset";

            resetPermissionsProcess.EnableRaisingEvents = true;
            resetPermissionsProcess.StartInfo = resetPermissionsStartInfo;

            // Start the process.
            resetPermissionsProcess.Start();

            // Wair for the process to finish.
            resetPermissionsProcess.WaitForExit();

            int exitCode = resetPermissionsProcess.ExitCode;
            bool resetPermissionsSuccessful = true;

            // Now we need to see if the process was successful.
            if (exitCode > 0 & !resetPermissionsProcess.HasExited)
            {
                resetPermissionsProcess.Kill();
                resetPermissionsSuccessful = false;
            }

            // Now clean up after ourselves.
            resetPermissionsProcess.Dispose();
            resetPermissionsStartInfo = null;
            return resetPermissionsSuccessful;
        }
        /// <summary>
        /// Sets owner of the file back to the TrustedInstaller.
        /// </summary>
        /// <param name="fileName">The file to process.</param>
        /// <returns>Sucessful operation.</returns>
        public static bool ResetOwner(string fileName)
        {
            Process resetOwnerProcess = new Process();
            ProcessStartInfo resetOwnerStartInfo = new ProcessStartInfo();

            resetOwnerStartInfo.FileName = "icacls.exe";

            // Do not write error output to standard stream.
            resetOwnerStartInfo.RedirectStandardError = false;
            // Do not write output to Process.StandardOutput Stream.
            resetOwnerStartInfo.RedirectStandardOutput = false;
            // Do not read input from Process.StandardInput (i/e; the keyboard).
            resetOwnerStartInfo.RedirectStandardInput = false;

            resetOwnerStartInfo.UseShellExecute = false;
            // Do not show a command window.
            resetOwnerStartInfo.CreateNoWindow = true;

            resetOwnerStartInfo.Arguments = fileName + " /setowner " + "\"" + "NT Service\\TrustedInstaller" + "\"";

            resetOwnerProcess.EnableRaisingEvents = true;
            resetOwnerProcess.StartInfo = resetOwnerStartInfo;

            // Start the process.
            resetOwnerProcess.Start();

            //Wait for the process to finish.
            resetOwnerProcess.WaitForExit();

            int exitCode = resetOwnerProcess.ExitCode;
            bool resetOwnerSuccessful = true;

            // Now we need to see if the process was successful.
            if (exitCode > 0 & !resetOwnerProcess.HasExited)
            {
                resetOwnerProcess.Kill();
                resetOwnerSuccessful = false;
            }

            // Now clean up after ourselves.
            resetOwnerProcess.Dispose();
            resetOwnerStartInfo = null;
            return resetOwnerSuccessful;
        }
        /// <summary>
        /// Uses Reshacker to patch the file.
        /// </summary>
        /// <param name="reshackerPath">Path to Reshacker executable.</param>
        /// <param name="scriptFile">Path to the Reshacker script.</param>
        /// <returns>Successful operation.</returns>
        public static bool ReshackFile(string reshackerPath, string scriptFile)
        {
            Process reshackFileProcess = new Process();
            ProcessStartInfo reshackFileStartInfo = new ProcessStartInfo();

            reshackFileStartInfo.FileName = reshackerPath;
            // Do not write error output to standard stream.
            reshackFileStartInfo.RedirectStandardError = false;
            // Do not write output to Process.StandardOutput Stream.
            reshackFileStartInfo.RedirectStandardOutput = false;
            // Do not read input from Process.StandardInput (i/e; the keyboard).
            reshackFileStartInfo.RedirectStandardInput = false;

            reshackFileStartInfo.UseShellExecute = false;
            // Do not show a command window.
            reshackFileStartInfo.CreateNoWindow = true;

            reshackFileStartInfo.Arguments = "-script " + "\"" + scriptFile + "\""; ;

            reshackFileProcess.EnableRaisingEvents = true;
            reshackFileProcess.StartInfo = reshackFileStartInfo;

            // Start the process.
            reshackFileProcess.Start();

            // Wait for the process to finish.
            reshackFileProcess.WaitForExit();

            int exitCode = reshackFileProcess.ExitCode;
            bool reshackFileSuccessful = true;

            // Now we need to see if the process was successful.
            if (exitCode > 0 & !reshackFileProcess.HasExited)
            {
                reshackFileProcess.Kill();
                reshackFileSuccessful = false;
            }

            // Now clean up after ourselves.
            reshackFileProcess.Dispose();
            reshackFileStartInfo = null;
            return reshackFileSuccessful;
        }
        /// <summary>
        /// Deletes a file on reboot.
        /// </summary>
        /// <param name="fileName">The file to delete.</param>
        /// <returns>Sucessful operaration.</returns>
        public static bool DeleteOnReboot(string fileName)
        {
            return MoveFileEx(fileName, null, MOVEFILE_DELAY_UNTIL_REBOOT);
        }
    }
}
