﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;

namespace Vize.VistaControls
{
    public partial class DBPanel : Panel
    {
        public DBPanel()
        {
            //InitLayout();
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        }
        //public DBPanel(IContainer container)
        //{
        //    container.Add(this);
        //    InitLayout();
        //    SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        //}
    }
}
