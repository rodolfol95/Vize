﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Xml;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;

namespace VizeReloadNotifier
{
    /// <summary>
    /// Main form.
    /// </summary>
    public partial class MainApp : Form
    {
        string AppPath { get; set; }
        string Language { get; set; }
        string LanguagesPath { get; set; }

        private string GetLocalizedText(string id)
        {
            // If not language file for this culture.
            if (!File.Exists(this.LanguagesPath + this.Language + ".xml"))
            {
                // Set "en-US" text as default culture;
                this.Language = "en-US";
            }

            if (!File.Exists(this.LanguagesPath + this.Language + ".xml"))
            {
                MessageBox.Show(this, "No default language file found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(-1);
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(this.LanguagesPath + this.Language + ".xml");

            XmlElement element = doc.GetElementById(id);

            if (element != null)
            {
                return element.InnerText;
            }
            else
            {
                return id + " value missing in translation.";
            }
        }

        public MainApp()
        {
            InitializeComponent();

            CultureInfo culture = Thread.CurrentThread.CurrentUICulture;
            this.Language = culture.Name;

            this.AppPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            this.LanguagesPath = this.AppPath + @"\Languages\";
        }

        private void LaunchElevatedProcess(string arg)
        {
            if (File.Exists(this.AppPath + @"\Vize.exe\"))
            {
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.UseShellExecute = true;
                startInfo.WorkingDirectory = Environment.CurrentDirectory;
                startInfo.FileName = @"Vize.exe";
                startInfo.Arguments = arg; 
                startInfo.Verb = "runas";

                Process p = Process.Start(startInfo);
                Application.Exit();
            }
            else
            {
                MessageBox.Show(this, "Failed to launch Vize Reloader.", "Vize Reload Notifier", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void MainApp_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();

            Thread.Sleep(10000);

            int files = GetNumberOfReloadFiles();

            if (files > 0)
            {
                this.notifyIcon.Visible = true;
                this.notifyIcon.ShowBalloonTip(10, "Vize Reload Notifier", files.ToString() + " " + GetLocalizedText("vizeReloadNotifierFound"), ToolTipIcon.Info);
            }
            else
            {
                Application.Exit();
            }
        }

        private void MainApp_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                this.Hide();
        }

        private int GetNumberOfReloadFiles()
        {
            int numberOfFiles = 0;

            if (File.Exists(this.AppPath + @"\FileList.xml"))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(this.AppPath + @"\FileList.xml");

                XmlNodeList fileList = doc.GetElementsByTagName("file");

                foreach (XmlNode node in fileList)
                {
                    XmlElement fileElement = node as XmlElement;

                    if (File.Exists(fileElement.Attributes["path"].InnerText))
                    {
                        FileInfo fileInfo = new FileInfo(fileElement.Attributes["path"].InnerText);

                        if (fileElement.Attributes["patched"].InnerText == "yes")
                        {
                            if (fileElement.Attributes["filesize"].InnerText != "" && fileElement.Attributes["filesize"].InnerText != fileInfo.Length.ToString())
                            {
                                numberOfFiles++;
                            }
                        }
                    }
                }
            }

            return numberOfFiles;
        }

        private void notifyIcon_BalloonTipClicked(object sender, EventArgs e)
        {
            LaunchReloader();
        }

        private void notifyIcon_BalloonTipClosed(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void notifyIcon_Click(object sender, EventArgs e)
        {
            LaunchReloader();
        }

        private void LaunchReloader()
        {
            LaunchElevatedProcess("Reloader");
        }
    }
}
