﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Vize.Properties;
using System.Threading;
using System.Xml;
using PatcherHelper;
using System.Security.Principal;
using System.Net;
using System.Reflection;
using Vize.VistaControls;
using System.Globalization;
using Microsoft.Win32;

namespace Vize
{
    /// <summary>
    /// The Vize pages.
    /// </summary>
    public enum VizePage
    {
        Home,
        Patcher,
        Restorer,
        Reloader,
        Options,
        About
    }
    /// <summary>
    /// The file types.
    /// </summary>
    public enum FileType
    {
        None,
        Dll,
        Exe,
        Cpl
    }
    /// <summary>
    /// The worker pages.
    /// </summary>
    public enum WorkerPage
    {
        None,
        Patcher,
        Reloader,
        Restorer
    }
    /// <summary>
    /// The dot.
    /// </summary>
    public enum Dot
    {
        None,
        Home,
        Links,
        Misc
    }
    /// <summary>
    /// Main form.
    /// </summary>
    public partial class MainApp : Form
    {
        #region Declarations

        string AppPath { get; set; }
        string ReshackerPath { get; set; }
        string BackupPath { get; set; }
        string ResourcesPath { get; set; }
        string NewFilesPath { get; set; }
        string LogsPath { get; set; }
        string FileListPath { get; set; }
        string LanguagesPath { get; set; }
        string Language { get; set; }

        bool RestartRequired { get; set; }
        bool DoNotAskReboot { get; set; }
        bool VizeProtectionEnabled { get; set; }
        bool VizeReloadNotifierEnabled { get; set; }

        const string APP_NAME = "7ize";
        const string APP_VERSION = "1.2";
        const string APP_STATUS = "Final";

        delegate void SetTextCallback(Label label, string text);
        delegate void SetProggressCallback(VistaControls.ProgressBar progressBar);

        List<string> errorList;

        #endregion
        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="args">Arguments needed for initialization.</param>
        public MainApp(string[] args)
        {
            InitializeComponent();

            errorList = new List<string>();
            this.AppPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            this.ReshackerPath = this.AppPath + @"\Tools\reshacker.exe";
            this.BackupPath = this.AppPath + @"\Backup\";
            this.ResourcesPath = this.AppPath + @"\Resources\";
            this.NewFilesPath = this.AppPath + @"\NewFiles\";
            this.LogsPath = this.AppPath + @"\Logs\";
            this.FileListPath = this.AppPath + "\\FileList.xml";
            this.LanguagesPath = this.AppPath + @"\Languages\";

            CultureInfo culture = Thread.CurrentThread.CurrentUICulture;
            this.Language = culture.Name;

            // Set title text.
            // this.Text = APP_NAME + " " + APP_VERSION + " " + APP_STATUS;
            this.Text = APP_NAME;

            #region Create pages and set properties

            this.pageAbout1 = new Vize.Pages.PageAbout();
            this.pageAbout1.LabelVersion.Text = "Version " + APP_VERSION + " " + APP_STATUS;
            this.pageAbout1.Location = new Point(184, 12);
            this.pageAbout1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            this.pageHome1 = new Vize.Pages.PageHome();
            this.pageHome1.Location = new Point(184, 12);
            this.pageHome1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            this.pagePatch1 = new Vize.Pages.PagePatch();
            this.pagePatch1.Location = new Point(184, 12);
            this.pagePatch1.ListPatchFiles.SmallImageList = this.imageListFileType;
            this.pagePatch1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            this.pageReloader1 = new Vize.Pages.PageReloader();
            this.pageReloader1.Location = new Point(184, 12);
            this.pageReloader1.ListReloadFiles.SmallImageList = this.imageListFileType;
            this.pageReloader1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            this.pageRestore1 = new Vize.Pages.PageRestore();
            this.pageRestore1.Location = new Point(184, 12);
            this.pageRestore1.ListRestoreFiles.SmallImageList = this.imageListFileType;
            this.pageRestore1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            this.pageOptions1 = new Vize.Pages.PageOptions();
            this.pageOptions1.Location = new Point(184, 12);
            this.pageOptions1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

            #endregion

            // Add pages to the form.
            this.Controls.Add(this.pageAbout1);
            this.Controls.Add(this.pageHome1);
            this.Controls.Add(this.pagePatch1);
            this.Controls.Add(this.pageReloader1);
            this.Controls.Add(this.pageRestore1);
            this.Controls.Add(this.pageOptions1);

            #region Events

            this.pageHome1.ButtonPatchPage.Click += new EventHandler(ButtonPatchPageClick);
            this.pageHome1.ButtonReloadPage.Click += new EventHandler(ButtonReloadPageClick);
            this.pageHome1.ButtonRestorePage.Click += new EventHandler(ButtonRestorePageClick);

            this.pagePatch1.ButtonPatch.Click += new EventHandler(ButtonPatchClick);
            this.pagePatch1.ComboPatchSelectFiles.SelectedIndexChanged += new EventHandler(ComboPatchSelectFilesSelectedIndexChanged);
            this.pagePatch1.LabelSeeErrors.Click += new EventHandler(LabelSeeErrorsClick);
            this.pagePatch1.ListPatchFiles.ItemSelectionChanged += new ListViewItemSelectionChangedEventHandler(ListPatchFilesItemSelectionChanged);

            this.pageRestore1.ComboRestorerSelectFiles.SelectedIndexChanged += new EventHandler(ComboRestorerSelectFilesSelectedIndexChanged);
            this.pageRestore1.LabelSeeErrors.Click += new EventHandler(LabelSeeErrorsClick);
            this.pageRestore1.ButtonRestore.Click += new EventHandler(ButtonRestoreClick);
            this.pageRestore1.ListRestoreFiles.ItemSelectionChanged += new ListViewItemSelectionChangedEventHandler(ListRestoreFilesItemSelectionChanged);

            this.pageReloader1.LabelSeeErrors.Click += new EventHandler(LabelSeeErrorsClick);
            this.pageReloader1.ButtonReloadCheck.Click += new EventHandler(ButtonReloadCheckClick);
            this.pageReloader1.ComboReloaderSelectFiles.SelectedIndexChanged += new EventHandler(ComboReloaderSelectFilesSelectedIndexChanged);
            this.pageReloader1.ListReloadFiles.ItemSelectionChanged += new ListViewItemSelectionChangedEventHandler(ListReloadFilesItemSelectionChanged);

            this.pageAbout1.ButtonVisitHomepage.Click += new EventHandler(ButtonVisitHomepageClick);
            this.pageOptions1.ButtonApply.Click += new EventHandler(ButtonApplyClick);

            #endregion

            // Sets localized text.
            SetCommonLocalizedText();

            #region Load settings

            this.VizeProtectionEnabled = Settings.Default.VizeProtectionEnabled;
            this.VizeReloadNotifierEnabled = Settings.Default.VizeReloadNotifierEnabled;

            this.WindowState = Settings.Default.State;
            this.Size = Settings.Default.Size;
            this.Location = Settings.Default.Location;

            this.pagePatch1.ListPatchFiles.Columns["File"].Width = Settings.Default.PatchFileColumn;
            this.pagePatch1.ListPatchFiles.Columns["Type"].Width = Settings.Default.PatchTypeColumn;
            this.pagePatch1.ListPatchFiles.Columns["ShipsWindows"].Width = Settings.Default.PatchShipWindowsColumn;
            this.pagePatch1.ListPatchFiles.Columns["Path"].Width = Settings.Default.PatchPathColumn;

            this.pageReloader1.ListReloadFiles.Columns["File"].Width = Settings.Default.ReloaderFileColumn;
            this.pageReloader1.ListReloadFiles.Columns["Type"].Width = Settings.Default.ReloaderTypeColumn;
            this.pageReloader1.ListReloadFiles.Columns["ShipsWindows"].Width = Settings.Default.ReloaderShipWindowsColumn;
            this.pageReloader1.ListReloadFiles.Columns["Path"].Width = Settings.Default.ReloaderPathColumn;

            this.pageRestore1.ListRestoreFiles.Columns["File"].Width = Settings.Default.RestorerFileColumn;
            this.pageRestore1.ListRestoreFiles.Columns["Type"].Width = Settings.Default.RestorerTypeColumn;
            this.pageRestore1.ListRestoreFiles.Columns["ShipsWindows"].Width = Settings.Default.RestorerShipWindowsColumn;
            this.pageRestore1.ListRestoreFiles.Columns["Path"].Width = Settings.Default.RestorerPathColumn;

            #endregion

            // Start in Home page.
            if (args.Length == 0)
            {
                MakePageVisible(VizePage.Home);
            }
            else
            {
                MakePageVisible(args[0]);
            }

            // Gets the drive letter where Vista is installed.
            GetVistaDriveLetter();
        }

        #region Load and Close

        private void MainAppLoad(object sender, EventArgs e)
        {


            // Check if Vista is installed in drive C:
            string vistaDriveLetter = GetVistaDriveLetter();

            if (vistaDriveLetter != @"C:\")
            {
                // Vista is not in drive C:
                ReplaceDriveInFileList(vistaDriveLetter);
            }

            this.Cursor = Cursors.AppStarting;

            if (!FileListExists())
            {
                MessageBox.Show("The file list information file could not be found.", "File list not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            this.pageOptions1.VizeProtectionEnabled = this.VizeProtectionEnabled;
            this.pageOptions1.VizeReloadNotifierEnabled = this.VizeReloadNotifierEnabled;

            this.Cursor = Cursors.Default;
        }

        private void MainAppFormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSettings();
        }

        #endregion

        #region Item Selection Changed

        private void SetDetailedInfo(string filePath)
        {
            try
            {
                GetFileInfo detailedFileInfo = new GetFileInfo(filePath);
                SetPatcherStatusMessage(detailedFileInfo.FileDescription, Resources.info, false);
            }
            catch
            {
                SetPatcherStatusMessage("Error retrieving file information.", Resources.warning, false);
            }
        }

        private void ListPatchFilesItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                SetDetailedInfo(e.Item.SubItems["Path"].Text);
            }
        }

        private void ListReloadFilesItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                SetDetailedInfo(e.Item.SubItems["Path"].Text);
            }
        }

        private void ListRestoreFilesItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                SetDetailedInfo(e.Item.SubItems["Path"].Text);
            }
        }

        #endregion

        #region Combos Index Changed

        private void ComboIndexChanged(VistaControls.ComboBox comboBox, VistaControls.ListView listView)
        {
            // 0 All files
            // 1 All Dll
            // 2 All Exe
            // 3 All Cpl

            if (comboBox.SelectedIndex == 1)
            {
                foreach (ListViewItem item in listView.Items)
                {
                    item.Checked = false;
                }

                foreach (ListViewItem item in listView.Items)
                {
                    if (item.SubItems[1].Text == "dll")
                    {
                        item.Checked = true;
                    }
                }
            }
            if (comboBox.SelectedIndex == 2)
            {
                foreach (ListViewItem item in listView.Items)
                {
                    item.Checked = false;
                }

                foreach (ListViewItem item in listView.Items)
                {
                    if (item.SubItems[1].Text == "exe")
                    {
                        item.Checked = true;
                    }
                }
            }

            if (comboBox.SelectedIndex == 3)
            {
                foreach (ListViewItem item in listView.Items)
                {
                    item.Checked = false;
                }

                foreach (ListViewItem item in listView.Items)
                {
                    if (item.SubItems[1].Text == "cpl")
                    {
                        item.Checked = true;
                    }
                }
            }

            if (comboBox.SelectedIndex == 0)
            {
                foreach (ListViewItem item in listView.Items)
                {
                    item.Checked = true;
                }
            }
        }

        private void ComboPatchSelectFilesSelectedIndexChanged(object sender, EventArgs e)
        {
            ComboIndexChanged(this.pagePatch1.ComboPatchSelectFiles, this.pagePatch1.ListPatchFiles);
        }

        private void ComboReloaderSelectFilesSelectedIndexChanged(object sender, EventArgs e)
        {
            ComboIndexChanged(this.pageReloader1.ComboReloaderSelectFiles, this.pageReloader1.ListReloadFiles);
        }

        private void ComboRestorerSelectFilesSelectedIndexChanged(object sender, EventArgs e)
        {
            ComboIndexChanged(this.pageRestore1.ComboRestorerSelectFiles, this.pageRestore1.ListRestoreFiles);
        }

        #endregion

        #region Fill Lists

        private void FillList(VistaControls.ListView listView, WorkerPage page)
        {
            if (FileListExists())
            {
                listView.Items.Clear();

                XmlDocument doc = new XmlDocument();
                doc.Load(this.FileListPath);

                XmlNodeList fileList = doc.GetElementsByTagName("file");

                foreach (XmlNode node in fileList)
                {
                    XmlElement fileElement = node as XmlElement;

                    if (File.Exists(fileElement.Attributes["path"].InnerText))
                    {
                        switch (page)
                        {
                            case WorkerPage.None:
                                break;
                            case WorkerPage.Patcher:
                                if (fileElement.Attributes["patched"].InnerText != "yes")
                                {
                                    if (fileElement.Attributes["type"].InnerText == "dll")
                                    {
                                        FillListInternal(this.pagePatch1.ListPatchFiles, fileElement, FileType.Dll);
                                    }
                                    if (fileElement.Attributes["type"].InnerText == "exe")
                                    {
                                        FillListInternal(this.pagePatch1.ListPatchFiles, fileElement, FileType.Exe);
                                    }
                                    if (fileElement.Attributes["type"].InnerText == "cpl")
                                    {
                                        FillListInternal(this.pagePatch1.ListPatchFiles, fileElement, FileType.Cpl);
                                    }
                                }
                                break;
                            case WorkerPage.Reloader:
                                FileInfo fileInfo = new FileInfo(fileElement.Attributes["path"].InnerText);

                                // Add file version too.
                                if (fileElement.Attributes["patched"].InnerText == "yes")
                                {
                                    if (fileElement.Attributes["filesize"].InnerText != "" && fileElement.Attributes["filesize"].InnerText != fileInfo.Length.ToString())
                                    {
                                        if (fileElement.Attributes["type"].InnerText == "dll")
                                        {
                                            FillListInternal(this.pageReloader1.ListReloadFiles, fileElement, FileType.Dll);
                                        }
                                        if (fileElement.Attributes["type"].InnerText == "exe")
                                        {
                                            FillListInternal(this.pageReloader1.ListReloadFiles, fileElement, FileType.Exe);
                                        }
                                        if (fileElement.Attributes["type"].InnerText == "cpl")
                                        {
                                            FillListInternal(this.pageReloader1.ListReloadFiles, fileElement, FileType.Cpl);
                                        }
                                    }
                                }
                                break;
                            case WorkerPage.Restorer:
                                if (fileElement.Attributes["patched"].InnerText == "yes")
                                {
                                    if (fileElement.Attributes["type"].InnerText == "dll")
                                    {
                                        FillListInternal(this.pageRestore1.ListRestoreFiles, fileElement, FileType.Dll);
                                    }
                                    if (fileElement.Attributes["type"].InnerText == "exe")
                                    {
                                        FillListInternal(this.pageRestore1.ListRestoreFiles, fileElement, FileType.Exe);
                                    }
                                    if (fileElement.Attributes["type"].InnerText == "cpl")
                                    {
                                        FillListInternal(this.pageRestore1.ListRestoreFiles, fileElement, FileType.Cpl);
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("The file list information file could not be found.", "File list not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void FillListInternal(VistaControls.ListView listView, XmlElement element, FileType type)
        {
            string yes = GetLocalizedText("yes");
            string no = GetLocalizedText("no");
            ListViewItem item = new ListViewItem();
            ListViewItem.ListViewSubItem typeItem = new ListViewItem.ListViewSubItem();
            ListViewItem.ListViewSubItem shipWindowsItem = new ListViewItem.ListViewSubItem();
            ListViewItem.ListViewSubItem pathItem = new ListViewItem.ListViewSubItem();

            switch (type)
            {
                case FileType.None:
                    break;
                case FileType.Dll:
                    item.ImageIndex = 0;
                    break;
                case FileType.Exe:
                    item.ImageIndex = 1;
                    break;
                case FileType.Cpl:
                    item.ImageIndex = 2;
                    break;
                default:
                    break;
            }

            item.Text = element.FirstChild.InnerText;
            item.Name = element.FirstChild.InnerText;
            typeItem.Text = element.Attributes["type"].InnerText;
            typeItem.Name = "Type";

            if (element.Attributes["shipswithwindows"].InnerText == "yes")
            {
                shipWindowsItem.Text = yes;
            }
            else
            {
                shipWindowsItem.Text = no;
            }

            shipWindowsItem.Name = "ShipsWindows";

            pathItem.Text = element.Attributes["path"].InnerText;
            pathItem.Name = "Path";

            item.SubItems.Add(typeItem);
            item.SubItems.Add(shipWindowsItem);
            item.SubItems.Add(pathItem);

            listView.Items.Add(item);
        }

        #endregion

        #region Clicks

        private void ButtonVisitHomepageClick(object sender, EventArgs e)
        {
            Process.Start("http://vmaxos.com");
        }

        private void ButtonPatchClick(object sender, EventArgs e)
        {
            PrepareForProcess(this.pagePatch1.ButtonPatch,
                this.pagePatch1.ListPatchFiles,
                this.pagePatch1.ComboPatchSelectFiles,
                this.pagePatch1.ProgressBarPatcher,
                this.patcherWorker,
                WorkerPage.Patcher);
        }

        private void ButtonReloadCheckClick(object sender, EventArgs e)
        {
            PrepareForProcess(this.pageReloader1.ButtonReloadCheck,
                this.pageReloader1.ListReloadFiles,
                this.pageReloader1.ComboReloaderSelectFiles,
                this.pageReloader1.ProgressBarReloader,
                this.reloaderWorker,
                WorkerPage.Reloader);
        }

        private void ButtonRestoreClick(object sender, EventArgs e)
        {
            PrepareForProcess(this.pageRestore1.ButtonRestore,
                this.pageRestore1.ListRestoreFiles,
                this.pageRestore1.ComboRestorerSelectFiles,
                this.pageRestore1.ProgressBarRestorer,
                this.restorerWorker,
                WorkerPage.Restorer);
        }

        private void ButtonPatchPageClick(object sender, EventArgs e)
        {
            GoToPage(VizePage.Patcher,
                this.restorerWorker,
                this.reloaderWorker,
                this.patcherWorker,
                this.pagePatch1.ButtonPatch,
                this.pagePatch1.ComboPatchSelectFiles,
                this.pagePatch1.ListPatchFiles,
                WorkerPage.Patcher);
        }

        private void ButtonReloadPageClick(object sender, EventArgs e)
        {
            GoToPage(VizePage.Reloader,
                this.patcherWorker,
                this.restorerWorker,
                this.reloaderWorker,
                this.pageReloader1.ButtonReloadCheck,
                this.pageReloader1.ComboReloaderSelectFiles,
                this.pageReloader1.ListReloadFiles,
                WorkerPage.Reloader);
        }

        private void ButtonRestorePageClick(object sender, EventArgs e)
        {
            GoToPage(VizePage.Restorer,
                this.patcherWorker,
                this.reloaderWorker,
                this.restorerWorker,
                this.pageRestore1.ButtonRestore,
                this.pageRestore1.ComboRestorerSelectFiles,
                this.pageRestore1.ListRestoreFiles,
                WorkerPage.Restorer);
        }

        private void ButtonApplyClick(object sender, EventArgs e)
        {
            // The path to the key where Windows looks for startup applications.
            RegistryKey rkApp = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);

            if (this.pageOptions1.VizeReloadNotifierEnabled)
            {
                if (rkApp.GetValue("Vize Reload Notifier") == null)
                {
                    // Add the value in the registry so that the application runs at startup.
                    rkApp.SetValue("Vize Reload Notifier", this.AppPath + @"\VizeReloadNotifier.exe");
                }
            }
            else
            {
                if (rkApp.GetValue("Vize Reload Notifier") != null)
                {
                    // Remove the value from the registry so that the application doesn't start.
                    rkApp.DeleteValue("Vize Reload Notifier", false);
                }
            }

            Settings.Default.VizeReloadNotifierEnabled = pageOptions1.VizeReloadNotifierEnabled;
            Settings.Default.VizeProtectionEnabled = pageOptions1.VizeProtectionEnabled;
            Settings.Default.Save();

            this.pageOptions1.LabelSettingsApplied.Visible = true;
        }

        private void lblTitleLeftClick(object sender, EventArgs e)
        {
            MakePageVisible(VizePage.Home);
            SetActiveDot(Dot.Home);
        }

        private void lblOptionsClick(object sender, EventArgs e)
        {
            MakePageVisible(VizePage.Options);
            SetActiveDot(Dot.Misc);

            this.pageOptions1.LabelSettingsApplied.Visible = false;
        }

        private void lblAboutClick(object sender, EventArgs e)
        {
            MakePageVisible(VizePage.About);
            SetActiveDot(Dot.Misc);
        }

        private void lblCheckUpdatesClick(object sender, EventArgs e)
        {
            SetActiveDot(Dot.Misc);

            this.Cursor = Cursors.WaitCursor;

            WebClient client = new WebClient();

            if (File.Exists(this.AppPath + "version.txt"))
            {
                try
                {
                    File.Delete(this.AppPath + "version.txt");
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            try
            {
                client.DownloadFile("http://vizeos.net/version/version.txt", "version.txt");
            }
            catch (WebException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Cursor = Cursors.Default;
                return;
            }

            StreamReader sr = File.OpenText("version.txt");
            string version = sr.ReadToEnd();
            sr.Close();

            string vizeUpdate = GetLocalizedText("vizeUpdate");
            this.Cursor = Cursors.Default;

            if (decimal.Parse(version) > decimal.Parse(APP_VERSION))
            {
                string yes = GetLocalizedText("yes");
                string no = GetLocalizedText("no");
                string vizeUpdateAvailable = GetLocalizedText("vizeUpdateAvailable");

                TaskDialog taskDialog = new TaskDialog();

                TaskDialogButton yesButton = new TaskDialogButton();
                yesButton.ButtonId = 101;
                yesButton.ButtonText = yes;

                TaskDialogButton noButton = new TaskDialogButton();
                noButton.ButtonId = 102;
                noButton.ButtonText = no;

                taskDialog.Buttons = new TaskDialogButton[] { yesButton, noButton };

                taskDialog.Content = vizeUpdateAvailable;
                taskDialog.MainIcon = TaskDialogIcon.Information;
                taskDialog.MainInstruction = vizeUpdate;
                taskDialog.PositionRelativeToWindow = true;
                taskDialog.WindowTitle = vizeUpdate;

                if (taskDialog.Show(this) == 101)
                {
                    Process.Start("http://vizeos.net/?page=downloads");
                }
            }
            else
            {
                string upToDate = GetLocalizedText("upToDate");
                string close = GetLocalizedText("close");

                TaskDialog taskDialog = new TaskDialog();

                TaskDialogButton closeButton = new TaskDialogButton();
                closeButton.ButtonId = 101;
                closeButton.ButtonText = close;

                taskDialog.Buttons = new TaskDialogButton[] { closeButton };

                taskDialog.Content = upToDate;
                taskDialog.MainIcon = TaskDialogIcon.Information;
                taskDialog.MainInstruction = vizeUpdate;
                taskDialog.PositionRelativeToWindow = true;
                taskDialog.WindowTitle = vizeUpdate;
                taskDialog.Show(this);
            }
        }

        private void LabelSeeErrorsClick(object sender, EventArgs e)
        {
            Process.Start(this.AppPath + "\\ErrorLog.txt");
        }

        #endregion

        #region Misc Methods

        private string GetVistaDriveLetter()
        {
            string vistaDriveLetter = String.Empty;
            string[] drives = Directory.GetLogicalDrives();

            for (int i = 0; i < drives.Length; i++)
            {
                if (File.Exists(drives[i] + @"Windows\explorer.exe"))
                {
                    FileVersionInfo explorerVersion = FileVersionInfo.GetVersionInfo(drives[i] + @"Windows\explorer.exe");

                    if (explorerVersion.FileMajorPart == 5)
                    {
                        vistaDriveLetter = drives[i];
                    }
                }
            }

            return vistaDriveLetter;
        }

        private void ReplaceDriveInFileList(string vistaDriveLetter)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(this.FileListPath);

            XmlNodeList fileList = doc.GetElementsByTagName("file");

            foreach (XmlNode node in fileList)
            {
                XmlElement fileElement = node as XmlElement;

                fileElement.Attributes["path"].InnerText = fileElement.Attributes["path"].InnerText.Replace(@"C:\", vistaDriveLetter);
            }

            // Save changes in FileList.xml.
            doc.Save("FileList.xml");
        }

        private string GetLocalizedText(string id)
        {
            // If not language file for this culture.
            if (!File.Exists(this.LanguagesPath + this.Language + ".xml"))
            {
                // Set "en-US" text as default culture;
                this.Language = "en-US";
            }

            if (!File.Exists(this.LanguagesPath + this.Language + ".xml"))
            {
                MessageBox.Show(this, "No default language file found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(-1);
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(this.LanguagesPath + this.Language + ".xml");

            XmlElement element = doc.GetElementById(id);

            if (element != null)
            {
                return element.InnerText;
            }
            else
            {
                return id + " value missing in translation.";
            }
        }

        private void SetCommonLocalizedText()
        {
            // If not language file for this culture.
            if (!File.Exists(this.LanguagesPath + this.Language + ".xml"))
            {
                // Set "en-US" text as default culture;
                this.Language = "en-US";
            }

            if (!File.Exists(this.LanguagesPath + this.Language + ".xml"))
            {
                MessageBox.Show(this, "No default language file found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(-1);
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(this.LanguagesPath + this.Language + ".xml");

            // MainApp
            this.lblTitleLeft.Text = doc.GetElementById("lblTitleLeft").InnerText;
            this.lblQuickLinks.Text = doc.GetElementById("lblQuickLinks").InnerText;
            this.lblMisc.Text = doc.GetElementById("lblMisc").InnerText;
            this.lblOptions.Text = doc.GetElementById("lblOptions").InnerText;
            this.lblCheckUpdates.Text = doc.GetElementById("lblCheckUpdates").InnerText;
            this.lblAbout.Text = doc.GetElementById("lblAbout").InnerText;

            //Home
            this.pageHome1.LabelTitleHome.Text = doc.GetElementById("lblTitleHome").InnerText;
            this.pageHome1.LabelDescHome.Text = doc.GetElementById("lblDescHome").InnerText;
            this.pageHome1.LabelChooseOption.Text = doc.GetElementById("lblChooseOption").InnerText;
            this.pageHome1.ButtonPatchPage.Text = doc.GetElementById("btnPatchPage").InnerText;
            this.pageHome1.ButtonPatchPage.Note = doc.GetElementById("btnPatchPageNote").InnerText;
            this.pageHome1.ButtonReloadPage.Text = doc.GetElementById("btnReloaderPage").InnerText;
            this.pageHome1.ButtonReloadPage.Note = doc.GetElementById("btnReloaderPageNote").InnerText;
            this.pageHome1.ButtonRestorePage.Text = doc.GetElementById("btnRestorerPage").InnerText;
            this.pageHome1.ButtonRestorePage.Note = doc.GetElementById("btnRestorerPageNote").InnerText;

            // About
            this.pageAbout1.LabelTitleAbout.Text = doc.GetElementById("lblTitleAbout").InnerText;
            this.pageAbout1.LabelDesc1About.Text = doc.GetElementById("lblDescAbout1").InnerText;
            this.pageAbout1.LabelDesc2About.Text = doc.GetElementById("lblDescAbout2").InnerText;
            this.pageAbout1.LabelDesc3About.Text = doc.GetElementById("lblDescAbout3").InnerText;
            this.pageAbout1.ButtonVisitHomepage.Text = doc.GetElementById("btnVisitHomepage").InnerText;
            this.pageAbout1.ButtonVisitHomepage.Note = doc.GetElementById("btnVisitHomepageNote").InnerText;
            this.pageAbout1.LabelTranslationAuthor.Text = doc.GetElementById("translationAuthor").InnerText;
            this.pageAbout1.LabelTranslation.Text = doc.GetElementById("lblTranslation").InnerText;

            //Options
            this.pageOptions1.LabelTitleOptions.Text = doc.GetElementById("lblTitleOptions").InnerText;
            this.pageOptions1.LabelDescOptions.Text = doc.GetElementById("lblDescOptions").InnerText;
            this.pageOptions1.LabelDescProtection.Text = doc.GetElementById("lblProtectionDesc").InnerText;
            this.pageOptions1.LabelSettingsApplied.Text = doc.GetElementById("lblSettingsApplied").InnerText;
            this.pageOptions1.ButtonApply.Text = doc.GetElementById("btnApply").InnerText;
            this.pageOptions1.RadioProtectionDisabled.Text = doc.GetElementById("radioProtectionDisabled").InnerText;
            this.pageOptions1.RadioProtectionEnabled.Text = doc.GetElementById("radioProtectionEnabled").InnerText;
            this.pageOptions1.LabelNotifierDesc.Text = doc.GetElementById("lblNotifierDesc").InnerText;
            this.pageOptions1.RadioNotifierEnabled.Text = doc.GetElementById("radioNotifierEnabled").InnerText;
            this.pageOptions1.RadioNotifierDisabled.Text = doc.GetElementById("radioNotifierDisabled").InnerText;

            //Patcher
            this.pagePatch1.LabelDescPatcher.Text = doc.GetElementById("lblDescPatcher").InnerText;
            this.pagePatch1.LabelSeeErrors.Text = doc.GetElementById("lblSeeErrors").InnerText;
            this.pagePatch1.ButtonPatch.Text = doc.GetElementById("btnPatch").InnerText;
            this.pagePatch1.ComboPatchSelectFiles.CueBannerText = doc.GetElementById("cmbSelectCueBanner").InnerText;
            this.pagePatch1.ComboPatchSelectFiles.Items[0] = doc.GetElementById("cmbSelectAll").InnerText;
            this.pagePatch1.ComboPatchSelectFiles.Items[1] = doc.GetElementById("cmbSelectDll").InnerText;
            this.pagePatch1.ComboPatchSelectFiles.Items[2] = doc.GetElementById("cmbSelectExe").InnerText;
            this.pagePatch1.ComboPatchSelectFiles.Items[3] = doc.GetElementById("cmbSelectCpl").InnerText;
            this.pagePatch1.ListPatchFiles.Columns[0].Text = doc.GetElementById("lstPatchFilesColumnFile").InnerText;
            this.pagePatch1.ListPatchFiles.Columns[1].Text = doc.GetElementById("lstPatchFilesColumnType").InnerText;
            this.pagePatch1.ListPatchFiles.Columns[2].Text = doc.GetElementById("lstPatchFilesColumnShipsWindows").InnerText;
            this.pagePatch1.ListPatchFiles.Columns[3].Text = doc.GetElementById("lstPatchFilesColumnPath").InnerText;

            //Reloader
            this.pageReloader1.LabelDescReloader.Text = doc.GetElementById("lblDescReloader").InnerText;
            this.pageReloader1.LabelSeeErrors.Text = doc.GetElementById("lblSeeErrors").InnerText;
            this.pageReloader1.ButtonReloadCheck.Text = doc.GetElementById("btnReload").InnerText;
            this.pageReloader1.ComboReloaderSelectFiles.CueBannerText = doc.GetElementById("cmbSelectCueBanner").InnerText;
            this.pageReloader1.ComboReloaderSelectFiles.Items[0] = doc.GetElementById("cmbSelectAll").InnerText;
            this.pageReloader1.ComboReloaderSelectFiles.Items[1] = doc.GetElementById("cmbSelectDll").InnerText;
            this.pageReloader1.ComboReloaderSelectFiles.Items[2] = doc.GetElementById("cmbSelectExe").InnerText;
            this.pageReloader1.ComboReloaderSelectFiles.Items[3] = doc.GetElementById("cmbSelectCpl").InnerText;
            this.pageReloader1.ListReloadFiles.Columns[0].Text = doc.GetElementById("lstReloadFilesColumnFile").InnerText;
            this.pageReloader1.ListReloadFiles.Columns[1].Text = doc.GetElementById("lstReloadFilesColumnType").InnerText;
            this.pageReloader1.ListReloadFiles.Columns[2].Text = doc.GetElementById("lstReloadFilesColumnShipsWindows").InnerText;
            this.pageReloader1.ListReloadFiles.Columns[3].Text = doc.GetElementById("lstReloadFilesColumnPath").InnerText;

            //Restorer
            this.pageRestore1.LabelDescRestore.Text = doc.GetElementById("lblDescRestorer").InnerText;
            this.pageRestore1.LabelSeeErrors.Text = doc.GetElementById("lblSeeErrors").InnerText;
            this.pageRestore1.ButtonRestore.Text = doc.GetElementById("btnRestore").InnerText;
            this.pageRestore1.ComboRestorerSelectFiles.CueBannerText = doc.GetElementById("cmbSelectCueBanner").InnerText;
            this.pageRestore1.ComboRestorerSelectFiles.Items[0] = doc.GetElementById("cmbSelectAll").InnerText;
            this.pageRestore1.ComboRestorerSelectFiles.Items[1] = doc.GetElementById("cmbSelectDll").InnerText;
            this.pageRestore1.ComboRestorerSelectFiles.Items[2] = doc.GetElementById("cmbSelectExe").InnerText;
            this.pageRestore1.ComboRestorerSelectFiles.Items[3] = doc.GetElementById("cmbSelectCpl").InnerText;
            this.pageRestore1.ListRestoreFiles.Columns[0].Text = doc.GetElementById("lstReloadFilesColumnFile").InnerText;
            this.pageRestore1.ListRestoreFiles.Columns[1].Text = doc.GetElementById("lstReloadFilesColumnType").InnerText;
            this.pageRestore1.ListRestoreFiles.Columns[2].Text = doc.GetElementById("lstReloadFilesColumnShipsWindows").InnerText;
            this.pageRestore1.ListRestoreFiles.Columns[3].Text = doc.GetElementById("lstReloadFilesColumnPath").InnerText;
        }

        private List<FileInfo> GetFilesToBeProcessed(WorkerPage page)
        {
            if (FileListExists())
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(this.FileListPath);

                XmlNodeList fileList = doc.GetElementsByTagName("file");

                List<FileInfo> filesToBeProcessed = new List<FileInfo>();

                foreach (XmlNode file in fileList)
                {
                    if (File.Exists(file.Attributes["path"].InnerText))
                    {
                        switch (page)
                        {
                            case WorkerPage.Patcher:
                                if (file.Attributes["patched"].InnerText == "no")
                                {
                                    if (this.pagePatch1.ListPatchFiles.Items[file.InnerText].Checked)
                                    {
                                        filesToBeProcessed.Add(new FileInfo(file.Attributes["path"].InnerText));
                                    }
                                }
                                break;
                            case WorkerPage.Reloader:
                                if (file.Attributes["patched"].InnerText == "yes")
                                {
                                    FileInfo fi = new FileInfo(file.Attributes["path"].InnerText);

                                    if (file.Attributes["filesize"].InnerText != fi.Length.ToString())
                                    {
                                        if (this.pageReloader1.ListReloadFiles.Items[file.InnerText].Checked)
                                        {
                                            filesToBeProcessed.Add(new FileInfo(file.Attributes["path"].InnerText));
                                        }
                                    }
                                }
                                break;
                            case WorkerPage.Restorer:
                                if (file.Attributes["patched"].InnerText == "yes")
                                {
                                    if (this.pageRestore1.ListRestoreFiles.Items[file.InnerText].Checked)
                                    {
                                        filesToBeProcessed.Add(new FileInfo(file.Attributes["path"].InnerText));
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }

                return filesToBeProcessed;
            }
            else
            {
                return null;
            }
        }

        private string GetNameFromWellKnownSid(WellKnownSidType wksid)
        {
            SecurityIdentifier sid = new SecurityIdentifier(wksid, null);
            NTAccount account = (NTAccount)sid.Translate(typeof(NTAccount));
            return account.Value;
        }

        private void GoToPage(VizePage page, BackgroundWorker worker1, BackgroundWorker worker2, BackgroundWorker worker3, VistaControls.Button button, VistaControls.ComboBox comboBox, VistaControls.ListView listView, WorkerPage workPage)
        {
            MakePageVisible(page);
            SetActiveDot(Dot.Links);
            string anotherTaskInProgress = GetLocalizedText("anotherTaskInProgress");
            string restartRequired = GetLocalizedText("restartRequired");
            string restart = GetLocalizedText("restart");
            string noFilesForPatching = GetLocalizedText("noFilesForPatching");
            string noFilesForReloading = GetLocalizedText("noFilesForReloading");
            string noFilesForRestoring = GetLocalizedText("noFilesForRestoring");
            string selectFileToPatch = GetLocalizedText("selectFileToPatch");
            string selectFileToReload = GetLocalizedText("selectFileToReload");
            string selectFileToRestore = GetLocalizedText("selectFileToRestore");

            if (worker1.IsBusy || worker2.IsBusy)
            {
                switch (workPage)
                {
                    case WorkerPage.None:
                        break;
                    case WorkerPage.Patcher:
                        SetPatcherStatusMessage(anotherTaskInProgress, Resources.warning, false);
                        break;
                    case WorkerPage.Reloader:
                        SetReloaderStatusMessage(anotherTaskInProgress, Resources.warning, false);
                        break;
                    case WorkerPage.Restorer:
                        SetRestorerStatusMessage(anotherTaskInProgress, Resources.warning, false);
                        break;
                    default:
                        break;
                }
                button.Enabled = false;
                comboBox.Enabled = false;
                return;
            }

            if (this.RestartRequired)
            {
                switch (workPage)
                {
                    case WorkerPage.None:
                        break;
                    case WorkerPage.Patcher:
                        SetPatcherStatusMessage(restartRequired, Resources.warning, false);
                        break;
                    case WorkerPage.Reloader:
                        SetReloaderStatusMessage(restartRequired, Resources.warning, false);
                        break;
                    case WorkerPage.Restorer:
                        SetRestorerStatusMessage(restartRequired, Resources.warning, false);
                        break;
                    default:
                        break;
                }
                button.Enabled = true;
                button.Image = Resources.warning;
                button.Text = restart;
                comboBox.Enabled = false;
                listView.Enabled = false;
                return;
            }

            if (!worker3.IsBusy)
            {
                this.Cursor = Cursors.WaitCursor;
                comboBox.Enabled = true;

                FillList(listView, workPage);

                if (listView.Items.Count == 0)
                {
                    button.Enabled = false;
                    comboBox.Enabled = false;
                    listView.Enabled = false;

                    switch (workPage)
                    {
                        case WorkerPage.None:
                            break;
                        case WorkerPage.Patcher:
                            SetPatcherStatusMessage(noFilesForPatching, Resources.info, false);
                            break;
                        case WorkerPage.Reloader:
                            SetReloaderStatusMessage(noFilesForReloading, Resources.info, false);
                            break;
                        case WorkerPage.Restorer:
                            SetRestorerStatusMessage(noFilesForRestoring, Resources.info, false);
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    button.Enabled = true;
                    comboBox.Enabled = true;

                    switch (workPage)
                    {
                        case WorkerPage.None:
                            break;
                        case WorkerPage.Patcher:
                            SetPatcherStatusMessage(selectFileToPatch, Resources.info, false);
                            break;
                        case WorkerPage.Reloader:
                            SetReloaderStatusMessage(selectFileToReload, Resources.info, false);
                            break;
                        case WorkerPage.Restorer:
                            SetRestorerStatusMessage(selectFileToRestore, Resources.info, false);
                            break;
                        default:
                            break;
                    }
                }

                this.Cursor = Cursors.Default;
            }
            else
            {
                comboBox.Enabled = false;
            }
        }

        private void SetActiveDot(Dot dot)
        {
            switch (dot)
            {
                case Dot.None:
                    break;
                case Dot.Home:
                    this.lblDotHome.Visible = true;
                    this.lblDotLinks.Visible = false;
                    this.lblDotMisc.Visible = false;
                    break;
                case Dot.Links:
                    this.lblDotHome.Visible = false;
                    this.lblDotLinks.Visible = true;
                    this.lblDotMisc.Visible = false;
                    break;
                case Dot.Misc:
                    this.lblDotHome.Visible = false;
                    this.lblDotLinks.Visible = false;
                    this.lblDotMisc.Visible = true;
                    break;
                default:
                    break;
            }
        }

        private void PrepareForProcess(VistaControls.Button button, VistaControls.ListView listView, System.Windows.Forms.ComboBox comboBox, VistaControls.ProgressBar progressBar, BackgroundWorker worker, WorkerPage page)
        {
            string restart = GetLocalizedText("restart");
            string preparing = GetLocalizedText("preparing");
            string atLeastOneFile = GetLocalizedText("atLeastOneFile");
            string yes = GetLocalizedText("yes");
            string no = GetLocalizedText("no");
            string pcNeedsRestart = GetLocalizedText("pcNeedsRestart");
            string restartYourComputer = GetLocalizedText("restartYourComputer");

            if (button.Text != restart)
            {
                if (FileListExists())
                {
                    if (listView.CheckedItems.Count != 0)
                    {
                        SetPatcherStatusMessage(preparing, Resources.info, false);

                        button.Enabled = false;
                        comboBox.Enabled = false;
                        listView.Enabled = false;

                        progressBar.Value = 0;
                        progressBar.Maximum = listView.CheckedItems.Count;
                        progressBar.Step = 1;

                        // Get list of files to be patched
                        List<FileInfo> filesToBeProcessed = GetFilesToBeProcessed(page);
                        worker.RunWorkerAsync(filesToBeProcessed);
                    }
                    else
                    {
                        switch (page)
                        {
                            case WorkerPage.None:
                                break;
                            case WorkerPage.Patcher:
                                SetPatcherStatusMessage(atLeastOneFile, Resources.warning, false);
                                break;
                            case WorkerPage.Reloader:
                                SetReloaderStatusMessage(atLeastOneFile, Resources.warning, false);
                                break;
                            case WorkerPage.Restorer:
                                SetRestorerStatusMessage(atLeastOneFile, Resources.warning, false);
                                break;
                            default:
                                break;
                        }
                    }
                }
                else
                {
                    // TODO: Before exiting, try to restore the XML backup. Function to be implemented.
                    MessageBox.Show("The file list information file could not be found. Application will now exit.", "File list not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
            }
            else
            {
                TaskDialog taskDialog = new TaskDialog();

                TaskDialogButton yesButton = new TaskDialogButton();
                yesButton.ButtonId = 101;
                yesButton.ButtonText = yes;

                TaskDialogButton noButton = new TaskDialogButton();
                noButton.ButtonId = 102;
                noButton.ButtonText = no;

                taskDialog.Buttons = new TaskDialogButton[] { yesButton, noButton };

                taskDialog.Content = pcNeedsRestart;
                taskDialog.MainIcon = TaskDialogIcon.Warning;
                taskDialog.MainInstruction = restartYourComputer;
                taskDialog.PositionRelativeToWindow = true;
                taskDialog.WindowTitle = restart;

                if (taskDialog.Show(this) == 101)
                {
                    RestartManager.ExitWindows(RestartOptions.Reboot, false);
                }
            }
        }

        private bool FileListExists()
        {
            return File.Exists(this.FileListPath);
        }

        private void MakePageVisible(VizePage page)
        {
            switch (page)
            {
                case VizePage.Home:
                    this.pageHome1.Visible = true;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    break;
                case VizePage.Patcher:
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = true;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    break;
                case VizePage.Restorer:
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = true;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    break;
                case VizePage.Reloader:
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = true;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    break;
                case VizePage.About:
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = true;
                    this.pageOptions1.Visible = false;
                    break;
                case VizePage.Options:
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = true;
                    break;
                default:
                    break;
            }
        }

        private void MakePageVisible(string page)
        {
            switch (page)
            {
                case "Home":
                    this.pageHome1.Visible = true;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    break;
                case "Patcher":
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = true;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    GoToPage(VizePage.Patcher,
                                this.restorerWorker,
                                this.reloaderWorker,
                                this.patcherWorker,
                                this.pagePatch1.ButtonPatch,
                                this.pagePatch1.ComboPatchSelectFiles,
                                this.pagePatch1.ListPatchFiles,
                                WorkerPage.Patcher);
                    break;
                case "Restorer":
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = true;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    GoToPage(VizePage.Restorer,
                                this.patcherWorker,
                                this.reloaderWorker,
                                this.restorerWorker,
                                this.pageRestore1.ButtonRestore,
                                this.pageRestore1.ComboRestorerSelectFiles,
                                this.pageRestore1.ListRestoreFiles,
                                WorkerPage.Restorer);
                    break;
                case "Reloader":
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = true;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    GoToPage(VizePage.Reloader,
                                this.patcherWorker,
                                this.restorerWorker,
                                this.reloaderWorker,
                                this.pageReloader1.ButtonReloadCheck,
                                this.pageReloader1.ComboReloaderSelectFiles,
                                this.pageReloader1.ListReloadFiles,
                                WorkerPage.Reloader);
                    break;
                case "Options":
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = true;
                    break;
                case "About":
                    this.pageHome1.Visible = false;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = true;
                    this.pageOptions1.Visible = false;
                    break;
                default:
                    this.pageHome1.Visible = true;
                    this.pagePatch1.Visible = false;
                    this.pageReloader1.Visible = false;
                    this.pageRestore1.Visible = false;
                    this.pageAbout1.Visible = false;
                    this.pageOptions1.Visible = false;
                    break;
            }
        }

        private void SetStatusMessage(Label label, PictureBox pic, LinkLabel link, string message, Image icon, bool enableSeeErrors)
        {
            label.Text = message;
            pic.Image = icon;

            if (enableSeeErrors)
            {
                link.Visible = true;
            }
            else
            {
                link.Visible = false;
            }
        }

        private void SetPatcherStatusMessage(string message, Image icon, bool enableSeeErrors)
        {
            SetStatusMessage(this.pagePatch1.LabelStatusPatch,
                this.pagePatch1.PicInfoPatcher,
                this.pagePatch1.LabelSeeErrors,
                message,
                icon,
                enableSeeErrors);
        }

        private void SetRestorerStatusMessage(string message, Image icon, bool enableSeeErrors)
        {
            SetStatusMessage(this.pageRestore1.LabelStatusRestore,
                this.pageRestore1.PicInfoRestorer,
                this.pageRestore1.LabelSeeErrors,
                message,
                icon,
                enableSeeErrors);
        }

        private void SetReloaderStatusMessage(string message, Image icon, bool enableSeeErrors)
        {
            SetStatusMessage(this.pageReloader1.LabelStatusReload,
                this.pageReloader1.PicInfoReloader,
                this.pageReloader1.LabelSeeErrors,
                message,
                icon,
                enableSeeErrors);
        }

        private void SetProgress(VistaControls.ProgressBar progressBar)
        {
            if (progressBar.InvokeRequired)
            {
                SetProggressCallback d = new SetProggressCallback(SetProgress);
                this.Invoke(d, new object[] { progressBar });
            }
            else
            {
                progressBar.PerformStep();
            }
        }

        private void SetText(Label label, string text)
        {
            if (label.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { label, text });
            }
            else
            {
                label.Text = text;
            }
        }

        private void CreateErrorLog()
        {
            string errorLog = this.AppPath + "\\ErrorLog.txt";

            if (File.Exists(errorLog))
            {
                File.Delete(errorLog);
            }

            using (StreamWriter sw = new StreamWriter(errorLog))
            {
                sw.WriteLine("##########################################");
                sw.WriteLine("Vize Error Log: " + DateTime.Now.ToString());
                sw.WriteLine("##########################################");
                sw.WriteLine("");

                foreach (string error in errorList)
                {
                    sw.WriteLine(error);
                }
            }

            //errorList.Clear();
        }

        private void SaveSettings()
        {
            Properties.Settings.Default.State = this.WindowState;

            if (this.WindowState == FormWindowState.Normal)
            {
                Properties.Settings.Default.Size = this.Size;
                Properties.Settings.Default.Location = this.Location;
            }
            else
            {
                Properties.Settings.Default.Size = this.RestoreBounds.Size;
                Properties.Settings.Default.Location = this.RestoreBounds.Location;
            }

            Settings.Default.PatchFileColumn = this.pagePatch1.ListPatchFiles.Columns["File"].Width;
            Settings.Default.PatchTypeColumn = this.pagePatch1.ListPatchFiles.Columns["Type"].Width;
            Settings.Default.PatchShipWindowsColumn = this.pagePatch1.ListPatchFiles.Columns["ShipsWindows"].Width;
            Settings.Default.PatchPathColumn = this.pagePatch1.ListPatchFiles.Columns["Path"].Width;

            Settings.Default.ReloaderFileColumn = this.pageReloader1.ListReloadFiles.Columns["File"].Width;
            Settings.Default.ReloaderTypeColumn = this.pageReloader1.ListReloadFiles.Columns["Type"].Width;
            Settings.Default.ReloaderShipWindowsColumn = this.pageReloader1.ListReloadFiles.Columns["ShipsWindows"].Width;
            Settings.Default.ReloaderPathColumn = this.pageReloader1.ListReloadFiles.Columns["Path"].Width;

            Settings.Default.RestorerFileColumn = this.pageRestore1.ListRestoreFiles.Columns["File"].Width;
            Settings.Default.RestorerTypeColumn = this.pageRestore1.ListRestoreFiles.Columns["Type"].Width;
            Settings.Default.RestorerShipWindowsColumn = this.pageRestore1.ListRestoreFiles.Columns["ShipsWindows"].Width;
            Settings.Default.RestorerPathColumn = this.pageRestore1.ListRestoreFiles.Columns["Path"].Width;

            Properties.Settings.Default.Save();
        }

        #endregion

        #region Workers

        private void patcherWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            List<FileInfo> filesToBeProcessed = e.Argument as List<FileInfo>;
            List<string> filesSuccessfullyProcessed = new List<string>();

            foreach (FileInfo file in filesToBeProcessed)
            {
                // If errors ocurrs, cancel process.
                if (patcherWorker.CancellationPending)
                {
                    break;
                }

                // If target file exists.
                if (File.Exists(file.FullName))
                {
                    // Set status text and progressbar
                    SetText(this.pagePatch1.LabelStatusPatch, file.Name);
                    SetProgress(this.pagePatch1.ProgressBarPatcher);

                    // Backup file.
                    //Delete file if already exists in backup folder
                    if (File.Exists(this.BackupPath + file.Name))
                    {
                        File.Delete(this.BackupPath + file.Name);
                    }
                    // Copy file to backup folder.
                    File.Copy(file.FullName, this.BackupPath + file.Name);
                    // If file successfully backed up.
                    if (File.Exists(this.BackupPath + file.Name))
                    {
                        // Start patching file.
                        bool reshackOK = PatcherFunctions.ReshackFile(this.ReshackerPath, this.ResourcesPath + file.Name + "\\" + file.Name + ".txt");
                        bool fileExistInNewFilesFolder = File.Exists(this.NewFilesPath + file.Name);

                        // If file successfully patched.
                        if (reshackOK && fileExistInNewFilesFolder)
                        {
                            // Take control of file.
                            bool takeOwnershipOK = PatcherFunctions.TakeOwnership(file.FullName);
                            bool grantFullControlOK = PatcherFunctions.GrantFullControl(file.FullName, GetNameFromWellKnownSid(WellKnownSidType.BuiltinAdministratorsSid));

                            // If take control of file OK.
                            if (takeOwnershipOK && grantFullControlOK)
                            {
                                // Replace file in target folder (rename target filename.ext target filename.old).
                                if (File.Exists(file.FullName + ".old"))
                                {
                                    try
                                    {
                                        File.Delete(file.FullName + ".old");
                                    }
                                    catch (IOException ex)
                                    {
                                        errorList.Add(ex.Message);
                                    }
                                }
                                try
                                {
                                    File.Move(file.FullName, file.FullName + ".old");
                                }
                                catch (IOException ex)
                                {
                                    errorList.Add(ex.Message);
                                }

                                // If file successfully renamed to .old.
                                if (File.Exists(file.FullName + ".old"))
                                {
                                    File.Copy(this.NewFilesPath + file.Name, file.FullName);

                                    // If file successfully copied from NewFiles to target dir.
                                    if (File.Exists(file.FullName))
                                    {
                                        bool deleteOnRebootOK = PatcherFunctions.DeleteOnReboot(file.FullName + ".old");

                                        //Get patched file size (useful for Reloader).
                                        string fileSize = file.Length.ToString();

                                        if (deleteOnRebootOK)
                                        {
                                            filesSuccessfullyProcessed.Add(file.FullName);

                                            // Restore file permissions
                                            bool resetOwnerOK = PatcherFunctions.ResetOwner(file.FullName);
                                            bool resetPermissionsOK = PatcherFunctions.ResetPermissions(file.FullName);

                                            if (!resetOwnerOK || !resetPermissionsOK)
                                            {
                                                // Error restoring permissions.
                                                errorList.Add("Restoring permissions failed in: " + file.FullName);
                                            }

                                            try
                                            {
                                                File.Delete(this.NewFilesPath + file.Name);
                                            }
                                            catch (IOException ex)
                                            {
                                                errorList.Add(ex.Message);
                                                PatcherFunctions.DeleteOnReboot(this.NewFilesPath + file.Name);
                                            }
                                        }
                                        else
                                        {
                                            errorList.Add("File not successfully marked to be deleted on next reboot: " + file.FullName + ".old");
                                        }
                                    }
                                    else
                                    {
                                        errorList.Add("File not successfully copied from NewFiles to target folder: " + file.FullName);
                                    }
                                }
                                else
                                {
                                    errorList.Add("File not successfully renamed to .old: " + file.FullName);
                                }
                            }
                            else
                            {
                                errorList.Add("Take control failed in: " + file.FullName);
                            }
                        }
                        else
                        {
                            errorList.Add("File not successfully reshacked: " + file.FullName);
                        }
                    }
                    else
                    {
                        errorList.Add("File not successfully backed up: " + file.FullName);
                    }
                }

                if (errorList.Count > 0)
                {
                    patcherWorker.CancelAsync();
                }
            }

            e.Result = filesSuccessfullyProcessed;
        }

        private void patcherWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            string restart = GetLocalizedText("restart");

            if (errorList.Count == 0)
            {
                string finishRestart = GetLocalizedText("finishRestart");
                SetPatcherStatusMessage(finishRestart, Resources.info, false);
                FillList(this.pagePatch1.ListPatchFiles, WorkerPage.Patcher);
            }
            else
            {
                string finishWithErrors = GetLocalizedText("finishWithErrors");
                CreateErrorLog();
                this.pagePatch1.ProgressBarPatcher.Value = this.pagePatch1.ProgressBarPatcher.Maximum;
                SetPatcherStatusMessage(finishWithErrors, Resources.warning, true);

                if (this.VizeProtectionEnabled)
                {
                    string moreInfo = GetLocalizedText("moreInfo");
                    string vizeProtectionText = GetLocalizedText("vizeProtectionText");
                    string lessInfo = GetLocalizedText("lessInfo");
                    string errorFound = GetLocalizedText("errorFound");
                    string pleaseReport = GetLocalizedText("pleaseReport");
                    string close = GetLocalizedText("close");

                    TaskDialog taskDialog = new TaskDialog();

                    TaskDialogButton closeButton = new TaskDialogButton();
                    closeButton.ButtonId = 101;
                    closeButton.ButtonText = close;

                    taskDialog.Buttons = new TaskDialogButton[] { closeButton };

                    taskDialog.CollapsedControlText = moreInfo;
                    taskDialog.Content = vizeProtectionText;
                    taskDialog.ExpandedControlText = lessInfo;
                    taskDialog.MainIcon = TaskDialogIcon.Shield;
                    taskDialog.MainInstruction = errorFound;
                    taskDialog.PositionRelativeToWindow = true;
                    taskDialog.WindowTitle = "Vize System Protection";
                    taskDialog.ExpandedInformation = errorList[0];
                    taskDialog.Footer = pleaseReport;
                    taskDialog.Show(this);

                    errorList.Clear();
                }
            }

            // Write to XML files successfully processed.
            List<string> filesSuccessfullyProcessed = e.Result as List<string>;


            // If there are files successfully processed.
            if (filesSuccessfullyProcessed.Count > 0)
            {
                // Set as patched in XML all those files in filesSuccessfullyProcessed.
                XmlDocument doc = new XmlDocument();
                doc.Load(this.FileListPath);

                XmlNodeList xmlFileList = doc.GetElementsByTagName("file");

                foreach (XmlNode node in xmlFileList)
                {
                    if (filesSuccessfullyProcessed.Contains(node.Attributes["path"].InnerText))
                    {
                        FileInfo fi = new FileInfo(node.Attributes["path"].InnerText);

                        node.Attributes["patched"].InnerText = "yes";
                        node.Attributes["filesize"].InnerText = fi.Length.ToString();
                    }
                }

                // Save changes in FileList.xml.
                doc.Save("FileList.xml");
            }

            this.pagePatch1.ButtonPatch.Enabled = true;
            this.pagePatch1.ButtonPatch.Text = restart;
            this.pagePatch1.ButtonPatch.Image = Resources.warning;
            this.RestartRequired = true;
        }

        private void restorerWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            List<FileInfo> filesToBeProcessed = e.Argument as List<FileInfo>;
            List<string> filesSuccessfullyProcessed = new List<string>();

            foreach (FileInfo file in filesToBeProcessed)
            {
                // If errors ocurred, cancel process.
                if (restorerWorker.CancellationPending)
                {
                    break;
                }

                // If target file exists.
                if (File.Exists(file.FullName))
                {
                    // If file to be restored exists.
                    if (File.Exists(this.BackupPath + file.Name))
                    {
                        // Set status text and progressbar.
                        SetText(this.pageRestore1.LabelStatusRestore, file.Name);
                        SetProgress(this.pageRestore1.ProgressBarRestorer);

                        // Take control of file.
                        bool takeOwnershipOK = PatcherFunctions.TakeOwnership(file.FullName);
                        bool grantFullControlOK = PatcherFunctions.GrantFullControl(file.FullName, GetNameFromWellKnownSid(WellKnownSidType.BuiltinAdministratorsSid));

                        if (takeOwnershipOK && grantFullControlOK)
                        {
                            // Replace file in target folder (rename target filename.ext target filename.old).
                            if (File.Exists(file.FullName + ".old"))
                            {
                                try
                                {
                                    File.Delete(file.FullName + ".old");
                                }
                                catch (IOException ex)
                                {
                                    errorList.Add(ex.Message);
                                }
                            }
                            try
                            {
                                File.Move(file.FullName, file.FullName + ".old");
                            }
                            catch (IOException ex)
                            {
                                errorList.Add(ex.Message);
                            }

                            // If file successfully renamed to .old.
                            if (File.Exists(file.FullName + ".old"))
                            {
                                // Restore file from backup folder.
                                File.Copy(this.BackupPath + file.Name, file.FullName);

                                // If file successfully copied from Backup to target dir.
                                if (File.Exists(file.FullName))
                                {
                                    bool deleteOnRebootOK = PatcherFunctions.DeleteOnReboot(file.FullName + ".old");

                                    if (deleteOnRebootOK)
                                    {
                                        filesSuccessfullyProcessed.Add(file.FullName);

                                        // Restore file permissions.
                                        bool resetOwnerOK = PatcherFunctions.ResetOwner(file.FullName);
                                        bool resetPermissionsOK = PatcherFunctions.ResetPermissions(file.FullName);

                                        if (!resetOwnerOK && !resetPermissionsOK)
                                        {
                                            errorList.Add("Restoring permissions failed in: " + file.FullName);
                                        }

                                        try
                                        {
                                            File.Delete(this.BackupPath + file.Name);
                                            File.Delete(this.LogsPath + file.Name + ".log");
                                        }
                                        catch (IOException ex)
                                        {
                                            errorList.Add(ex.Message);
                                            PatcherFunctions.DeleteOnReboot(this.BackupPath + file.Name);
                                            PatcherFunctions.DeleteOnReboot(this.LogsPath + file.Name + ".log");
                                        }
                                    }
                                    else
                                    {
                                        errorList.Add("File not successfully marked to be deleted on next reboot: " + file.FullName + ".old");
                                    }
                                }
                                else
                                {
                                    errorList.Add("File not successfully copied from Backup to target folder: " + file.FullName);
                                }
                            }
                            else
                            {
                                errorList.Add("File not successfully renamed to .old: " + file.FullName);
                            }
                        }
                        else
                        {
                            errorList.Add("Taking control failed in: " + file.FullName);
                        }
                    }
                    else
                    {
                        errorList.Add("File to be restored not found in Backup: " + file.FullName);
                    }
                }
                if (errorList.Count > 0)
                {
                    restorerWorker.CancelAsync();
                }
            }

            e.Result = filesSuccessfullyProcessed;
        }

        private void restorerWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            string restart = GetLocalizedText("restart");

            if (errorList.Count == 0)
            {
                string finishRestart = GetLocalizedText("finishRestart");
                SetRestorerStatusMessage(finishRestart, Resources.info, false);
                FillList(this.pageRestore1.ListRestoreFiles, WorkerPage.Restorer);
            }
            else
            {
                string finishWithErrors = GetLocalizedText("finishWithErrors");
                CreateErrorLog();
                SetRestorerStatusMessage(finishWithErrors, Resources.warning, true);

                if (this.VizeProtectionEnabled)
                {
                    string moreInfo = GetLocalizedText("moreInfo");
                    string vizeProtectionText = GetLocalizedText("vizeProtectionText");
                    string lessInfo = GetLocalizedText("lessInfo");
                    string errorFound = GetLocalizedText("errorFound");
                    string pleaseReport = GetLocalizedText("pleaseReport");
                    string close = GetLocalizedText("close");

                    TaskDialog taskDialog = new TaskDialog();

                    TaskDialogButton closeButton = new TaskDialogButton();
                    closeButton.ButtonId = 101;
                    closeButton.ButtonText = close;

                    taskDialog.Buttons = new TaskDialogButton[] { closeButton };

                    taskDialog.CollapsedControlText = moreInfo;
                    taskDialog.Content = vizeProtectionText;
                    taskDialog.ExpandedControlText = lessInfo;
                    taskDialog.MainIcon = TaskDialogIcon.Shield;
                    taskDialog.MainInstruction = errorFound;
                    taskDialog.PositionRelativeToWindow = true;
                    taskDialog.WindowTitle = "Vize System Protection";
                    taskDialog.ExpandedInformation = errorList[0];
                    taskDialog.Footer = pleaseReport; ;
                    taskDialog.Show(this);

                    errorList.Clear();
                }
            }

            List<string> filesSuccessfullyProcessed = e.Result as List<string>;

            // If there are files successfully patched
            if (filesSuccessfullyProcessed.Count > 0)
            {
                // Set as patched in XML all those files in filesSuccessfullyProcessed
                XmlDocument doc = new XmlDocument();
                doc.Load(this.FileListPath);

                XmlNodeList xmlFileList = doc.GetElementsByTagName("file");

                foreach (XmlNode node in xmlFileList)
                {
                    if (filesSuccessfullyProcessed.Contains(node.Attributes["path"].InnerText))
                    {
                        node.Attributes["patched"].InnerText = "no";
                        node.Attributes["filesize"].InnerText = "";
                        //node.Attributes["fileversion"].InnerText = fileVersion;
                    }
                }

                // Save changes in FileList.xml
                doc.Save("FileList.xml");
            }

            //this.pageRestore1.ComboRestorerSelectFiles.Enabled = true;
            //this.pageRestore1.ListRestoreFiles.Enabled = true;
            this.pageRestore1.ButtonRestore.Enabled = true;
            this.pageRestore1.ButtonRestore.Text = restart; ;
            this.pageRestore1.ButtonRestore.Image = Resources.warning;
            this.RestartRequired = true;
        }

        private void reloaderWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            List<FileInfo> filesToBeProcessed = e.Argument as List<FileInfo>;
            List<string> filesSuccessfullyProcessed = new List<string>();

            foreach (FileInfo file in filesToBeProcessed)
            {
                // If errors ocurred, cancel process.
                if (reloaderWorker.CancellationPending)
                {
                    break;
                }

                // If target file exists.
                if (File.Exists(file.FullName))
                {
                    // Set status text and progressbar
                    SetText(this.pageReloader1.LabelStatusReload, file.Name);
                    SetProgress(this.pageReloader1.ProgressBarReloader);

                    // Backup file.
                    //Delete file if already exists in backup folder.
                    if (File.Exists(this.BackupPath + file.Name))
                    {
                        File.Delete(this.BackupPath + file.Name);
                    }
                    // Copy file to backup folder.
                    File.Copy(file.FullName, this.BackupPath + file.Name);
                    // If file successfully backed up.
                    if (File.Exists(this.BackupPath + file.Name))
                    {
                        // Start patching.
                        bool reshackOK = PatcherFunctions.ReshackFile(this.ReshackerPath, this.ResourcesPath + file.Name + "\\" + file.Name + ".txt");
                        bool fileExistInNewFilesFolder = File.Exists(this.NewFilesPath + file.Name);

                        // If file successfully patched.
                        if (reshackOK && fileExistInNewFilesFolder)
                        {
                            // Restore file permissions.
                            bool takeOwnershipOK = PatcherFunctions.TakeOwnership(file.FullName);
                            bool grantFullControlOK = PatcherFunctions.GrantFullControl(file.FullName, GetNameFromWellKnownSid(WellKnownSidType.BuiltinAdministratorsSid));

                            if (takeOwnershipOK && grantFullControlOK)
                            {
                                // Replace file in target folder (rename target filename.ext target filename.old).
                                if (File.Exists(file.FullName + ".old"))
                                {
                                    try
                                    {
                                        File.Delete(file.FullName + ".old");
                                    }
                                    catch (IOException ex)
                                    {
                                        errorList.Add(ex.Message);
                                    }
                                }
                                try
                                {
                                    File.Move(file.FullName, file.FullName + ".old");
                                }
                                catch (IOException ex)
                                {
                                    errorList.Add(ex.Message);
                                }

                                // If file successfully renamed to .old.
                                if (File.Exists(file.FullName + ".old"))
                                {
                                    File.Copy(this.NewFilesPath + file.Name, file.FullName);

                                    // If file successfully copied from NewFiles to target dir.
                                    if (File.Exists(file.FullName))
                                    {
                                        bool deleteOnRebootOK = PatcherFunctions.DeleteOnReboot(file.FullName + ".old");

                                        //Get patched file size (useful for Reloader).
                                        string fileSize = file.Length.ToString();

                                        if (deleteOnRebootOK)
                                        {
                                            filesSuccessfullyProcessed.Add(file.FullName);

                                            // Restore file permissions.
                                            bool resetOwnerOK = PatcherFunctions.ResetOwner(file.FullName);
                                            bool resetPermissionsOK = PatcherFunctions.ResetPermissions(file.FullName);

                                            if (!resetOwnerOK && !resetPermissionsOK)
                                            {
                                                errorList.Add("Retoring permissions failed in: " + file.FullName);
                                            }

                                            try
                                            {
                                                File.Delete(this.NewFilesPath + file.Name);
                                            }
                                            catch (IOException ex)
                                            {
                                                errorList.Add(ex.Message);
                                                PatcherFunctions.DeleteOnReboot(this.NewFilesPath + file.Name);
                                            }
                                        }
                                        else
                                        {
                                            errorList.Add("File not successfully marked to be deleted on next reboot: " + file.FullName + ".old");
                                        }
                                    }
                                    else
                                    {
                                        errorList.Add("File not successfully copied from NewFiles to target folder: " + file.FullName);
                                    }
                                }
                                else
                                {
                                    errorList.Add("File not successfully renamed to .old: " + file.FullName);
                                }
                            }
                            else
                            {
                                errorList.Add("Taking control failed in: " + file.FullName);
                            }
                        }
                        else
                        {
                            errorList.Add("File not successfully reshacked: " + file.FullName);
                        }
                    }
                    else
                    {
                        errorList.Add("File not successfully backed up: " + file.FullName);
                    }
                }

                if (errorList.Count > 0)
                {
                    reloaderWorker.CancelAsync();
                }
            }

            e.Result = filesSuccessfullyProcessed;
        }

        private void reloaderWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            string restart = GetLocalizedText("restart");

            if (errorList.Count == 0)
            {
                string finishRestart = GetLocalizedText("finishRestart");
                SetReloaderStatusMessage(finishRestart, Resources.info, false);
                FillList(this.pageReloader1.ListReloadFiles, WorkerPage.Reloader);
            }
            else
            {
                string finishWithErrors = GetLocalizedText("finishWithErrors");
                CreateErrorLog();
                SetReloaderStatusMessage(finishWithErrors, Resources.warning, true);

                if (this.VizeProtectionEnabled)
                {
                    string moreInfo = GetLocalizedText("moreInfo");
                    string vizeProtectionText = GetLocalizedText("vizeProtectionText");
                    string lessInfo = GetLocalizedText("lessInfo");
                    string errorFound = GetLocalizedText("errorFound");
                    string pleaseReport = GetLocalizedText("pleaseReport");
                    string close = GetLocalizedText("close");

                    TaskDialog taskDialog = new TaskDialog();

                    TaskDialogButton closeButton = new TaskDialogButton();
                    closeButton.ButtonId = 101;
                    closeButton.ButtonText = close;

                    taskDialog.Buttons = new TaskDialogButton[] { closeButton };

                    taskDialog.CollapsedControlText = moreInfo;
                    taskDialog.Content = vizeProtectionText;
                    taskDialog.ExpandedControlText = lessInfo;
                    taskDialog.MainIcon = TaskDialogIcon.Shield;
                    taskDialog.MainInstruction = errorFound;
                    taskDialog.PositionRelativeToWindow = true;
                    taskDialog.WindowTitle = "Vize System Protection";
                    taskDialog.ExpandedInformation = errorList[0];
                    taskDialog.Footer = pleaseReport;
                    taskDialog.Show(this);

                    errorList.Clear();
                }
            }

            List<string> filesSuccessfullyProcessed = e.Result as List<string>;

            // If there are files successfully patched
            if (filesSuccessfullyProcessed.Count > 0)
            {
                // Set as patched in XML all those files in filesSuccessfullyProcessed
                XmlDocument doc = new XmlDocument();
                doc.Load(this.FileListPath);

                XmlNodeList xmlFileList = doc.GetElementsByTagName("file");

                foreach (XmlNode node in xmlFileList)
                {
                    if (filesSuccessfullyProcessed.Contains(node.Attributes["path"].InnerText))
                    {
                        FileInfo f = new FileInfo(node.Attributes["path"].InnerText);

                        node.Attributes["filesize"].InnerText = f.Length.ToString();
                        //node.Attributes["fileversion"].InnerText = fileVersion;
                    }
                }

                // Save changes in FileList.xml
                doc.Save("FileList.xml");
            }
            //this.pageReloader1.ComboReloaderSelectFiles.Enabled = true;
            //this.pageReloader1.ListReloadFiles.Enabled = true;
            this.pageReloader1.ButtonReloadCheck.Enabled = true;
            this.pageReloader1.ButtonReloadCheck.Text = "Restart";
            this.pageReloader1.ButtonReloadCheck.Image = Resources.warning;
            this.RestartRequired = true;
        }

        #endregion

        #region SetUnderlineText

        private void lblTitleLeft_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblTitleLeft, 9.75F, FontStyle.Underline);
        }

        private void lblTitleLeft_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblTitleLeft, 9.75F, FontStyle.Regular);
        }

        private void lblPatcher_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblPatcher, 9F, FontStyle.Underline);
        }

        private void lblPatcher_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblPatcher, 9F, FontStyle.Regular);
        }

        private void lblReloader_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblReloader, 9F, FontStyle.Underline);
        }

        private void lblReloader_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblReloader, 9F, FontStyle.Regular);
        }

        private void lblRestorer_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblRestorer, 9F, FontStyle.Underline);
        }

        private void lblRestorer_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblRestorer, 9F, FontStyle.Regular);
        }

        private void lblOptions_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblOptions, 9F, FontStyle.Underline);
        }

        private void lblOptions_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblOptions, 9F, FontStyle.Regular);
        }

        private void lblAbout_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblAbout, 9F, FontStyle.Underline);
        }

        private void lblAbout_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblAbout, 9F, FontStyle.Regular);
        }

        private void lblCheckUpdates_MouseHover(object sender, EventArgs e)
        {
            SetFont(this.lblCheckUpdates, 9F, FontStyle.Underline);
        }

        private void lblCheckUpdates_MouseLeave(object sender, EventArgs e)
        {
            SetFont(this.lblCheckUpdates, 9F, FontStyle.Regular);
        }

        private static void SetFont(Control control, float emSize, FontStyle fontStyle)
        {
            control.Font = new System.Drawing.Font("Segoe UI", emSize, fontStyle);
        }

        #endregion
    }
}
