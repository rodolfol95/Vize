﻿namespace Vize.Pages
{
    partial class PageOptions
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblNotifierDesc = new System.Windows.Forms.Label();
            this.radioNotifierDisabled = new System.Windows.Forms.RadioButton();
            this.picNotifierDisabled = new System.Windows.Forms.PictureBox();
            this.radioNotifierEnabled = new System.Windows.Forms.RadioButton();
            this.picNotifierEnabled = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblProtectionDesc = new System.Windows.Forms.Label();
            this.radioProtectionDisabled = new System.Windows.Forms.RadioButton();
            this.picProtectionDisabled = new System.Windows.Forms.PictureBox();
            this.radioProtectionEnabled = new System.Windows.Forms.RadioButton();
            this.picProtectionEnabled = new System.Windows.Forms.PictureBox();
            this.picReloadNotifier = new System.Windows.Forms.PictureBox();
            this.gbxReloadNotifier = new System.Windows.Forms.Label();
            this.gbxVizeProtection = new System.Windows.Forms.Label();
            this.picLineProtection = new System.Windows.Forms.PictureBox();
            this.lblSettingsApplied = new System.Windows.Forms.Label();
            this.btnApply = new Vize.VistaControls.Button();
            this.lblDescOptions = new System.Windows.Forms.Label();
            this.lblTitleOptions = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picNotifierDisabled)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNotifierEnabled)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProtectionDisabled)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProtectionEnabled)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picReloadNotifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLineProtection)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.picReloadNotifier);
            this.panel1.Controls.Add(this.gbxReloadNotifier);
            this.panel1.Controls.Add(this.gbxVizeProtection);
            this.panel1.Controls.Add(this.picLineProtection);
            this.panel1.Controls.Add(this.lblSettingsApplied);
            this.panel1.Controls.Add(this.btnApply);
            this.panel1.Controls.Add(this.lblDescOptions);
            this.panel1.Controls.Add(this.lblTitleOptions);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 440);
            this.panel1.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lblNotifierDesc);
            this.panel3.Controls.Add(this.radioNotifierDisabled);
            this.panel3.Controls.Add(this.picNotifierDisabled);
            this.panel3.Controls.Add(this.radioNotifierEnabled);
            this.panel3.Controls.Add(this.picNotifierEnabled);
            this.panel3.Location = new System.Drawing.Point(7, 235);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(462, 132);
            this.panel3.TabIndex = 23;
            // 
            // lblNotifierDesc
            // 
            this.lblNotifierDesc.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNotifierDesc.Location = new System.Drawing.Point(52, 30);
            this.lblNotifierDesc.Name = "lblNotifierDesc";
            this.lblNotifierDesc.Size = new System.Drawing.Size(407, 47);
            this.lblNotifierDesc.TabIndex = 26;
            this.lblNotifierDesc.Text = "Vize Reload Notifier informs you when system files need reloading.";
            // 
            // radioNotifierDisabled
            // 
            this.radioNotifierDisabled.AutoSize = true;
            this.radioNotifierDisabled.Checked = true;
            this.radioNotifierDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioNotifierDisabled.Location = new System.Drawing.Point(55, 80);
            this.radioNotifierDisabled.Name = "radioNotifierDisabled";
            this.radioNotifierDisabled.Size = new System.Drawing.Size(70, 17);
            this.radioNotifierDisabled.TabIndex = 25;
            this.radioNotifierDisabled.TabStop = true;
            this.radioNotifierDisabled.Text = "Disabled";
            this.radioNotifierDisabled.UseVisualStyleBackColor = true;
            // 
            // picNotifierDisabled
            // 
            this.picNotifierDisabled.Image = global::Vize.Properties.Resources.notifierdisabled;
            this.picNotifierDisabled.Location = new System.Drawing.Point(9, 72);
            this.picNotifierDisabled.Name = "picNotifierDisabled";
            this.picNotifierDisabled.Size = new System.Drawing.Size(40, 40);
            this.picNotifierDisabled.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picNotifierDisabled.TabIndex = 24;
            this.picNotifierDisabled.TabStop = false;
            // 
            // radioNotifierEnabled
            // 
            this.radioNotifierEnabled.AutoSize = true;
            this.radioNotifierEnabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioNotifierEnabled.Location = new System.Drawing.Point(55, 10);
            this.radioNotifierEnabled.Name = "radioNotifierEnabled";
            this.radioNotifierEnabled.Size = new System.Drawing.Size(67, 17);
            this.radioNotifierEnabled.TabIndex = 23;
            this.radioNotifierEnabled.Text = "Enabled";
            this.radioNotifierEnabled.UseVisualStyleBackColor = true;
            // 
            // picNotifierEnabled
            // 
            this.picNotifierEnabled.Image = global::Vize.Properties.Resources.notifierenabled;
            this.picNotifierEnabled.Location = new System.Drawing.Point(9, 3);
            this.picNotifierEnabled.Name = "picNotifierEnabled";
            this.picNotifierEnabled.Size = new System.Drawing.Size(40, 40);
            this.picNotifierEnabled.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picNotifierEnabled.TabIndex = 22;
            this.picNotifierEnabled.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblProtectionDesc);
            this.panel2.Controls.Add(this.radioProtectionDisabled);
            this.panel2.Controls.Add(this.picProtectionDisabled);
            this.panel2.Controls.Add(this.radioProtectionEnabled);
            this.panel2.Controls.Add(this.picProtectionEnabled);
            this.panel2.Location = new System.Drawing.Point(7, 94);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(465, 122);
            this.panel2.TabIndex = 22;
            // 
            // lblProtectionDesc
            // 
            this.lblProtectionDesc.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblProtectionDesc.Location = new System.Drawing.Point(52, 30);
            this.lblProtectionDesc.Name = "lblProtectionDesc";
            this.lblProtectionDesc.Size = new System.Drawing.Size(407, 48);
            this.lblProtectionDesc.TabIndex = 9;
            this.lblProtectionDesc.Text = "Vize System Protection cancels operations when the first error is found.";
            // 
            // radioProtectionDisabled
            // 
            this.radioProtectionDisabled.AutoSize = true;
            this.radioProtectionDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioProtectionDisabled.Location = new System.Drawing.Point(55, 81);
            this.radioProtectionDisabled.Name = "radioProtectionDisabled";
            this.radioProtectionDisabled.Size = new System.Drawing.Size(41, 17);
            this.radioProtectionDisabled.TabIndex = 8;
            this.radioProtectionDisabled.Text = "Off";
            this.radioProtectionDisabled.UseVisualStyleBackColor = true;
            // 
            // picProtectionDisabled
            // 
            this.picProtectionDisabled.Image = global::Vize.Properties.Resources.redshield;
            this.picProtectionDisabled.Location = new System.Drawing.Point(9, 73);
            this.picProtectionDisabled.Name = "picProtectionDisabled";
            this.picProtectionDisabled.Size = new System.Drawing.Size(40, 40);
            this.picProtectionDisabled.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picProtectionDisabled.TabIndex = 7;
            this.picProtectionDisabled.TabStop = false;
            // 
            // radioProtectionEnabled
            // 
            this.radioProtectionEnabled.AutoSize = true;
            this.radioProtectionEnabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioProtectionEnabled.Location = new System.Drawing.Point(55, 10);
            this.radioProtectionEnabled.Name = "radioProtectionEnabled";
            this.radioProtectionEnabled.Size = new System.Drawing.Size(126, 17);
            this.radioProtectionEnabled.TabIndex = 6;
            this.radioProtectionEnabled.Text = "On (recommended)";
            this.radioProtectionEnabled.UseVisualStyleBackColor = true;
            // 
            // picProtectionEnabled
            // 
            this.picProtectionEnabled.Image = global::Vize.Properties.Resources.greenshield;
            this.picProtectionEnabled.Location = new System.Drawing.Point(9, 3);
            this.picProtectionEnabled.Name = "picProtectionEnabled";
            this.picProtectionEnabled.Size = new System.Drawing.Size(40, 40);
            this.picProtectionEnabled.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picProtectionEnabled.TabIndex = 5;
            this.picProtectionEnabled.TabStop = false;
            // 
            // picReloadNotifier
            // 
            this.picReloadNotifier.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picReloadNotifier.Image = global::Vize.Properties.Resources.line;
            this.picReloadNotifier.Location = new System.Drawing.Point(119, 227);
            this.picReloadNotifier.Name = "picReloadNotifier";
            this.picReloadNotifier.Size = new System.Drawing.Size(350, 1);
            this.picReloadNotifier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picReloadNotifier.TabIndex = 16;
            this.picReloadNotifier.TabStop = false;
            // 
            // gbxReloadNotifier
            // 
            this.gbxReloadNotifier.AutoSize = true;
            this.gbxReloadNotifier.Location = new System.Drawing.Point(4, 219);
            this.gbxReloadNotifier.Name = "gbxReloadNotifier";
            this.gbxReloadNotifier.Size = new System.Drawing.Size(109, 13);
            this.gbxReloadNotifier.TabIndex = 15;
            this.gbxReloadNotifier.Text = "Vize Reload Notifier";
            // 
            // gbxVizeProtection
            // 
            this.gbxVizeProtection.AutoSize = true;
            this.gbxVizeProtection.Location = new System.Drawing.Point(4, 78);
            this.gbxVizeProtection.Name = "gbxVizeProtection";
            this.gbxVizeProtection.Size = new System.Drawing.Size(122, 13);
            this.gbxVizeProtection.TabIndex = 13;
            this.gbxVizeProtection.Text = "Vize System Protection";
            // 
            // picLineProtection
            // 
            this.picLineProtection.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picLineProtection.Image = global::Vize.Properties.Resources.line;
            this.picLineProtection.Location = new System.Drawing.Point(132, 85);
            this.picLineProtection.Name = "picLineProtection";
            this.picLineProtection.Size = new System.Drawing.Size(340, 1);
            this.picLineProtection.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLineProtection.TabIndex = 12;
            this.picLineProtection.TabStop = false;
            // 
            // lblSettingsApplied
            // 
            this.lblSettingsApplied.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSettingsApplied.AutoSize = true;
            this.lblSettingsApplied.Location = new System.Drawing.Point(13, 418);
            this.lblSettingsApplied.Name = "lblSettingsApplied";
            this.lblSettingsApplied.Size = new System.Drawing.Size(157, 13);
            this.lblSettingsApplied.TabIndex = 11;
            this.lblSettingsApplied.Text = "Options successfully applied.";
            this.lblSettingsApplied.Visible = false;
            // 
            // btnApply
            // 
            this.btnApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnApply.Location = new System.Drawing.Point(403, 412);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(85, 25);
            this.btnApply.TabIndex = 7;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            // 
            // lblDescOptions
            // 
            this.lblDescOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescOptions.Location = new System.Drawing.Point(4, 40);
            this.lblDescOptions.Name = "lblDescOptions";
            this.lblDescOptions.Size = new System.Drawing.Size(480, 38);
            this.lblDescOptions.TabIndex = 1;
            this.lblDescOptions.Text = "Configure Vize to your liking enabling or disabling the features below.";
            // 
            // lblTitleOptions
            // 
            this.lblTitleOptions.AutoSize = true;
            this.lblTitleOptions.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTitleOptions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.lblTitleOptions.Location = new System.Drawing.Point(3, 3);
            this.lblTitleOptions.Name = "lblTitleOptions";
            this.lblTitleOptions.Size = new System.Drawing.Size(65, 21);
            this.lblTitleOptions.TabIndex = 0;
            this.lblTitleOptions.Text = "Options";
            // 
            // PageOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "PageOptions";
            this.Size = new System.Drawing.Size(500, 440);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picNotifierDisabled)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNotifierEnabled)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProtectionDisabled)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picProtectionEnabled)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picReloadNotifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLineProtection)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDescOptions;
        private System.Windows.Forms.Label lblTitleOptions;
        private VistaControls.Button btnApply;
        private System.Windows.Forms.Label lblSettingsApplied;
        private System.Windows.Forms.PictureBox picLineProtection;
        private System.Windows.Forms.Label gbxVizeProtection;
        private System.Windows.Forms.Label gbxReloadNotifier;
        private System.Windows.Forms.PictureBox picReloadNotifier;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblNotifierDesc;
        private System.Windows.Forms.RadioButton radioNotifierDisabled;
        private System.Windows.Forms.PictureBox picNotifierDisabled;
        private System.Windows.Forms.RadioButton radioNotifierEnabled;
        private System.Windows.Forms.PictureBox picNotifierEnabled;
        private System.Windows.Forms.Label lblProtectionDesc;
        private System.Windows.Forms.RadioButton radioProtectionDisabled;
        private System.Windows.Forms.PictureBox picProtectionDisabled;
        private System.Windows.Forms.RadioButton radioProtectionEnabled;
        private System.Windows.Forms.PictureBox picProtectionEnabled;
    }
}
