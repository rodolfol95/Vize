﻿namespace Vize.Pages
{
    partial class PageReloader
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PageReloader));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.linkSeeErrorsReloader = new System.Windows.Forms.LinkLabel();
            this.lblStatusReloader = new System.Windows.Forms.Label();
            this.picInfoReloader = new System.Windows.Forms.PictureBox();
            this.lstReloadFiles = new Vize.VistaControls.ListView();
            this.File = new System.Windows.Forms.ColumnHeader();
            this.Type = new System.Windows.Forms.ColumnHeader();
            this.ShipsWindows = new System.Windows.Forms.ColumnHeader();
            this.Path = new System.Windows.Forms.ColumnHeader();
            this.btnReload = new Vize.VistaControls.Button();
            this.progressBarReloader = new Vize.VistaControls.ProgressBar();
            this.cmbSelect = new Vize.VistaControls.ComboBox();
            this.lblDescReloader = new System.Windows.Forms.Label();
            this.lblTitleReloader = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panelInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfoReloader)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panelInfo);
            this.panel1.Controls.Add(this.lstReloadFiles);
            this.panel1.Controls.Add(this.btnReload);
            this.panel1.Controls.Add(this.progressBarReloader);
            this.panel1.Controls.Add(this.cmbSelect);
            this.panel1.Controls.Add(this.lblDescReloader);
            this.panel1.Controls.Add(this.lblTitleReloader);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 440);
            this.panel1.TabIndex = 5;
            // 
            // panelInfo
            // 
            this.panelInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(199)))));
            this.panelInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelInfo.Controls.Add(this.linkSeeErrorsReloader);
            this.panelInfo.Controls.Add(this.lblStatusReloader);
            this.panelInfo.Controls.Add(this.picInfoReloader);
            this.panelInfo.Location = new System.Drawing.Point(11, 363);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(477, 22);
            this.panelInfo.TabIndex = 4;
            // 
            // linkSeeErrorsReloader
            // 
            this.linkSeeErrorsReloader.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.linkSeeErrorsReloader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkSeeErrorsReloader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkSeeErrorsReloader.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.linkSeeErrorsReloader.Location = new System.Drawing.Point(359, 4);
            this.linkSeeErrorsReloader.Name = "linkSeeErrorsReloader";
            this.linkSeeErrorsReloader.Size = new System.Drawing.Size(113, 13);
            this.linkSeeErrorsReloader.TabIndex = 1;
            this.linkSeeErrorsReloader.TabStop = true;
            this.linkSeeErrorsReloader.Text = "See errors";
            this.linkSeeErrorsReloader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkSeeErrorsReloader.Visible = false;
            this.linkSeeErrorsReloader.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            // 
            // lblStatusReloader
            // 
            this.lblStatusReloader.AutoSize = true;
            this.lblStatusReloader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblStatusReloader.Location = new System.Drawing.Point(26, 4);
            this.lblStatusReloader.Name = "lblStatusReloader";
            this.lblStatusReloader.Size = new System.Drawing.Size(235, 13);
            this.lblStatusReloader.TabIndex = 0;
            this.lblStatusReloader.Text = "Select which files to reload and click Reload.";
            // 
            // picInfoReloader
            // 
            this.picInfoReloader.Image = global::Vize.Properties.Resources.info;
            this.picInfoReloader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.picInfoReloader.Location = new System.Drawing.Point(3, 2);
            this.picInfoReloader.Name = "picInfoReloader";
            this.picInfoReloader.Size = new System.Drawing.Size(16, 16);
            this.picInfoReloader.TabIndex = 0;
            this.picInfoReloader.TabStop = false;
            // 
            // lstReloadFiles
            // 
            this.lstReloadFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstReloadFiles.CheckBoxes = true;
            this.lstReloadFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.File,
            this.Type,
            this.ShipsWindows,
            this.Path});
            this.lstReloadFiles.FullRowSelect = true;
            this.lstReloadFiles.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstReloadFiles.Location = new System.Drawing.Point(11, 130);
            this.lstReloadFiles.Name = "lstReloadFiles";
            this.lstReloadFiles.Size = new System.Drawing.Size(477, 227);
            this.lstReloadFiles.TabIndex = 3;
            this.lstReloadFiles.UseCompatibleStateImageBehavior = false;
            this.lstReloadFiles.View = System.Windows.Forms.View.Details;
            // 
            // File
            // 
            this.File.Name = "File";
            this.File.Text = "File";
            this.File.Width = 170;
            // 
            // Type
            // 
            this.Type.Name = "Type";
            this.Type.Text = "Type";
            this.Type.Width = 50;
            // 
            // ShipsWindows
            // 
            this.ShipsWindows.Name = "ShipsWindows";
            this.ShipsWindows.Text = "Ships with Windows";
            this.ShipsWindows.Width = 130;
            // 
            // Path
            // 
            this.Path.Name = "Path";
            this.Path.Text = "Path";
            this.Path.Width = 300;
            // 
            // btnReload
            // 
            this.btnReload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnReload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReload.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnReload.Location = new System.Drawing.Point(403, 412);
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(85, 25);
            this.btnReload.TabIndex = 6;
            this.btnReload.Text = "Reload";
            this.btnReload.UseVisualStyleBackColor = true;
            // 
            // progressBarReloader
            // 
            this.progressBarReloader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarReloader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.progressBarReloader.Location = new System.Drawing.Point(11, 391);
            this.progressBarReloader.Name = "progressBarReloader";
            this.progressBarReloader.Size = new System.Drawing.Size(477, 15);
            this.progressBarReloader.TabIndex = 5;
            // 
            // cmbSelect
            // 
            this.cmbSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSelect.CueBannerText = "Select files";
            this.cmbSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelect.Enabled = false;
            this.cmbSelect.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbSelect.FormattingEnabled = true;
            this.cmbSelect.Items.AddRange(new object[] {
            "All",
            "All Dll",
            "All Exe",
            "All Cpl"});
            this.cmbSelect.Location = new System.Drawing.Point(346, 103);
            this.cmbSelect.Name = "cmbSelect";
            this.cmbSelect.Size = new System.Drawing.Size(142, 21);
            this.cmbSelect.TabIndex = 2;
            // 
            // lblDescReloader
            // 
            this.lblDescReloader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescReloader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDescReloader.Location = new System.Drawing.Point(4, 40);
            this.lblDescReloader.Name = "lblDescReloader";
            this.lblDescReloader.Size = new System.Drawing.Size(484, 60);
            this.lblDescReloader.TabIndex = 1;
            //this.lblDescReloader.Text = resources.GetString("lblDescReloader.Text");
            // 
            // lblTitleReloader
            // 
            this.lblTitleReloader.AutoSize = true;
            this.lblTitleReloader.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTitleReloader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.lblTitleReloader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTitleReloader.Location = new System.Drawing.Point(3, 3);
            this.lblTitleReloader.Name = "lblTitleReloader";
            this.lblTitleReloader.Size = new System.Drawing.Size(105, 21);
            this.lblTitleReloader.TabIndex = 0;
            this.lblTitleReloader.Text = "Vize Reloader";
            // 
            // PageReloader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Name = "PageReloader";
            this.Size = new System.Drawing.Size(500, 440);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfoReloader)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private VistaControls.Button btnReload;
        private VistaControls.ProgressBar progressBarReloader;
        private VistaControls.ComboBox cmbSelect;
        private System.Windows.Forms.Label lblDescReloader;
        private System.Windows.Forms.Label lblTitleReloader;
        private VistaControls.ListView lstReloadFiles;
        //private System.Windows.Forms.ColumnHeader columnHeaderFile;
        //private System.Windows.Forms.ColumnHeader columnHeaderType;
        //private System.Windows.Forms.ColumnHeader columnHeaderShipWindows;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.LinkLabel linkSeeErrorsReloader;
        private System.Windows.Forms.Label lblStatusReloader;
        private System.Windows.Forms.PictureBox picInfoReloader;
        //private System.Windows.Forms.ColumnHeader columnHeaderPath;
        private System.Windows.Forms.ColumnHeader File;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader ShipsWindows;
        private System.Windows.Forms.ColumnHeader Path;
    }
}
