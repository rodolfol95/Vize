﻿using System.ComponentModel;
using System.Windows.Forms;

namespace Vize.Pages
{
    public partial class PageRestore : UserControl
    {
        public PageRestore()
        {
            InitializeComponent();
        }

        public VistaControls.ComboBox ComboRestorerSelectFiles
        {
            get
            {
                return this.cmbSelect;
            }
            set
            {
                this.cmbSelect = value;
            }

        }

        public VistaControls.ListView ListRestoreFiles
        {
            get
            {
                return this.lstRestoreFiles;
            }
            set
            {
                this.lstRestoreFiles = value;
            }

        }

        public VistaControls.ProgressBar ProgressBarRestorer
        {
            get
            {
                return this.progressBarRestorer;
            }
            set
            {
                this.progressBarRestorer = value;
            }

        }

        public VistaControls.Button ButtonRestore
        {
            get
            {
                return this.btnRestore;
            }
            set
            {
                this.btnRestore = value;
            }

        }

        public Label LabelStatusRestore
        {
            get
            {
                return this.lblStatusRestorer;
            }
            set
            {
                this.lblStatusRestorer = value;
            }

        }

        public Label LabelDescRestore
        {
            get
            {
                return this.lblDescRestorer;
            }
            set
            {
                this.lblDescRestorer = value;
            }

        }

        public PictureBox PicInfoRestorer
        {
            get
            {
                return this.picInfoRestorer;
            }
            set
            {
                this.picInfoRestorer = value;
            }
        }

        public LinkLabel LabelSeeErrors
        {
            get
            {
                return this.linkSeeErrorsRestorer;
            }
            set
            {
                this.linkSeeErrorsRestorer = value;
            }

        }
    }
}
