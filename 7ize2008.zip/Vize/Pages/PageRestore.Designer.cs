﻿namespace Vize.Pages
{
    partial class PageRestore
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbSelect = new Vize.VistaControls.ComboBox();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.linkSeeErrorsRestorer = new System.Windows.Forms.LinkLabel();
            this.lblStatusRestorer = new System.Windows.Forms.Label();
            this.picInfoRestorer = new System.Windows.Forms.PictureBox();
            this.lstRestoreFiles = new Vize.VistaControls.ListView();
            this.File = new System.Windows.Forms.ColumnHeader();
            this.Type = new System.Windows.Forms.ColumnHeader();
            this.ShipsWindows = new System.Windows.Forms.ColumnHeader();
            this.Path = new System.Windows.Forms.ColumnHeader();
            this.btnRestore = new Vize.VistaControls.Button();
            this.progressBarRestorer = new Vize.VistaControls.ProgressBar();
            this.lblDescRestorer = new System.Windows.Forms.Label();
            this.lblTitleRestorer = new System.Windows.Forms.Label();
            this.columnHeaderFile = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderType = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderPatched = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderShipWindows = new System.Windows.Forms.ColumnHeader();
            this.panel1.SuspendLayout();
            this.panelInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfoRestorer)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.cmbSelect);
            this.panel1.Controls.Add(this.panelInfo);
            this.panel1.Controls.Add(this.lstRestoreFiles);
            this.panel1.Controls.Add(this.btnRestore);
            this.panel1.Controls.Add(this.progressBarRestorer);
            this.panel1.Controls.Add(this.lblDescRestorer);
            this.panel1.Controls.Add(this.lblTitleRestorer);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 440);
            this.panel1.TabIndex = 4;
            // 
            // cmbSelect
            // 
            this.cmbSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSelect.CueBannerText = "Select files";
            this.cmbSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelect.Enabled = false;
            this.cmbSelect.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbSelect.FormattingEnabled = true;
            this.cmbSelect.Items.AddRange(new object[] {
            "All",
            "All Dll",
            "All Exe",
            "All Cpl"});
            this.cmbSelect.Location = new System.Drawing.Point(346, 103);
            this.cmbSelect.Name = "cmbSelect";
            this.cmbSelect.Size = new System.Drawing.Size(142, 21);
            this.cmbSelect.TabIndex = 2;
            // 
            // panelInfo
            // 
            this.panelInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(199)))));
            this.panelInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelInfo.Controls.Add(this.linkSeeErrorsRestorer);
            this.panelInfo.Controls.Add(this.lblStatusRestorer);
            this.panelInfo.Controls.Add(this.picInfoRestorer);
            this.panelInfo.Location = new System.Drawing.Point(11, 363);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(477, 22);
            this.panelInfo.TabIndex = 4;
            // 
            // linkSeeErrorsRestorer
            // 
            this.linkSeeErrorsRestorer.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.linkSeeErrorsRestorer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkSeeErrorsRestorer.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.linkSeeErrorsRestorer.Location = new System.Drawing.Point(359, 4);
            this.linkSeeErrorsRestorer.Name = "linkSeeErrorsRestorer";
            this.linkSeeErrorsRestorer.Size = new System.Drawing.Size(113, 13);
            this.linkSeeErrorsRestorer.TabIndex = 1;
            this.linkSeeErrorsRestorer.TabStop = true;
            this.linkSeeErrorsRestorer.Text = "See errors";
            this.linkSeeErrorsRestorer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkSeeErrorsRestorer.Visible = false;
            this.linkSeeErrorsRestorer.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            // 
            // lblStatusRestorer
            // 
            this.lblStatusRestorer.AutoSize = true;
            this.lblStatusRestorer.Location = new System.Drawing.Point(26, 4);
            this.lblStatusRestorer.Name = "lblStatusRestorer";
            this.lblStatusRestorer.Size = new System.Drawing.Size(241, 13);
            this.lblStatusRestorer.TabIndex = 0;
            this.lblStatusRestorer.Text = "Select which files to restore and click Restore.";
            // 
            // picInfoRestorer
            // 
            this.picInfoRestorer.Image = global::Vize.Properties.Resources.info;
            this.picInfoRestorer.Location = new System.Drawing.Point(3, 2);
            this.picInfoRestorer.Name = "picInfoRestorer";
            this.picInfoRestorer.Size = new System.Drawing.Size(16, 16);
            this.picInfoRestorer.TabIndex = 0;
            this.picInfoRestorer.TabStop = false;
            // 
            // lstRestoreFiles
            // 
            this.lstRestoreFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstRestoreFiles.CheckBoxes = true;
            this.lstRestoreFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.File,
            this.Type,
            this.ShipsWindows,
            this.Path});
            this.lstRestoreFiles.FullRowSelect = true;
            this.lstRestoreFiles.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstRestoreFiles.Location = new System.Drawing.Point(11, 130);
            this.lstRestoreFiles.Name = "lstRestoreFiles";
            this.lstRestoreFiles.Size = new System.Drawing.Size(477, 227);
            this.lstRestoreFiles.TabIndex = 3;
            this.lstRestoreFiles.UseCompatibleStateImageBehavior = false;
            this.lstRestoreFiles.View = System.Windows.Forms.View.Details;
            // 
            // File
            // 
            this.File.Name = "File";
            this.File.Text = "File";
            this.File.Width = 170;
            // 
            // Type
            // 
            this.Type.Name = "Type";
            this.Type.Text = "Type";
            this.Type.Width = 50;
            // 
            // ShipsWindows
            // 
            this.ShipsWindows.Name = "ShipsWindows";
            this.ShipsWindows.Text = "Ships with Windows";
            this.ShipsWindows.Width = 130;
            // 
            // Path
            // 
            this.Path.Name = "Path";
            this.Path.Text = "Path";
            this.Path.Width = 300;
            // 
            // btnRestore
            // 
            this.btnRestore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestore.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRestore.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRestore.Location = new System.Drawing.Point(403, 412);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(85, 25);
            this.btnRestore.TabIndex = 6;
            this.btnRestore.Text = "Restore";
            this.btnRestore.UseVisualStyleBackColor = true;
            // 
            // progressBarRestorer
            // 
            this.progressBarRestorer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarRestorer.Location = new System.Drawing.Point(11, 391);
            this.progressBarRestorer.Name = "progressBarRestorer";
            this.progressBarRestorer.Size = new System.Drawing.Size(477, 15);
            this.progressBarRestorer.TabIndex = 5;
            // 
            // lblDescRestorer
            // 
            this.lblDescRestorer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescRestorer.Location = new System.Drawing.Point(4, 40);
            this.lblDescRestorer.Name = "lblDescRestorer";
            this.lblDescRestorer.Size = new System.Drawing.Size(484, 60);
            this.lblDescRestorer.TabIndex = 1;
            this.lblDescRestorer.Text = "Vize Restorer lets you restore the original Windows files in case you are not sat" +
                "isfied with the Vize modifications.";
            // 
            // lblTitleRestorer
            // 
            this.lblTitleRestorer.AutoSize = true;
            this.lblTitleRestorer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTitleRestorer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.lblTitleRestorer.Location = new System.Drawing.Point(3, 3);
            this.lblTitleRestorer.Name = "lblTitleRestorer";
            this.lblTitleRestorer.Size = new System.Drawing.Size(102, 21);
            this.lblTitleRestorer.TabIndex = 0;
            this.lblTitleRestorer.Text = "Vize Restorer";
            // 
            // columnHeaderFile
            // 
            this.columnHeaderFile.Text = "File";
            this.columnHeaderFile.Width = 160;
            // 
            // columnHeaderType
            // 
            this.columnHeaderType.Text = "Type";
            // 
            // columnHeaderPatched
            // 
            this.columnHeaderPatched.Text = "Patched";
            // 
            // columnHeaderShipWindows
            // 
            this.columnHeaderShipWindows.Text = "Ships with Windows";
            this.columnHeaderShipWindows.Width = 127;
            // 
            // PageRestore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Name = "PageRestore";
            this.Size = new System.Drawing.Size(500, 440);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfoRestorer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private VistaControls.Button btnRestore;
        private VistaControls.ProgressBar progressBarRestorer;
        private System.Windows.Forms.Label lblDescRestorer;
        private System.Windows.Forms.Label lblTitleRestorer;
        private System.Windows.Forms.ColumnHeader columnHeaderFile;
        private System.Windows.Forms.ColumnHeader columnHeaderType;
        private System.Windows.Forms.ColumnHeader columnHeaderPatched;
        private System.Windows.Forms.ColumnHeader columnHeaderShipWindows;
        private VistaControls.ListView lstRestoreFiles;
        //private System.Windows.Forms.ColumnHeader columnHeader1;
        //private System.Windows.Forms.ColumnHeader columnHeader2;
        //private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.LinkLabel linkSeeErrorsRestorer;
        private System.Windows.Forms.Label lblStatusRestorer;
        private System.Windows.Forms.PictureBox picInfoRestorer;
        private VistaControls.ComboBox cmbSelect;
        //private System.Windows.Forms.ColumnHeader columnHeaderPath;
        private System.Windows.Forms.ColumnHeader File;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader ShipsWindows;
        private System.Windows.Forms.ColumnHeader Path;
    }
}
