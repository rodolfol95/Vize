﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Vize.Pages
{
    public partial class PageOptions : UserControl
    {
        public PageOptions()
        {
            InitializeComponent();
        }

        public Label LabelTitleOptions
        {
            get
            {
                return this.lblTitleOptions;
            }
            set
            {
                this.lblTitleOptions = value;
            }
        }

        public Label LabelDescOptions
        {
            get
            {
                return this.lblDescOptions;
            }
            set
            {
                this.lblDescOptions = value;
            }
        }

        public Label GroupBoxVizeProtection
        {
            get
            {
                return this.gbxVizeProtection;
            }
            set
            {
                this.gbxVizeProtection = value;
            }
        }

        public RadioButton RadioProtectionEnabled
        {
            get
            {
                return this.radioProtectionEnabled;
            }
            set
            {
                this.radioProtectionEnabled = value;
            }
        }

        public RadioButton RadioProtectionDisabled
        {
            get
            {
                return this.radioProtectionDisabled;
            }
            set
            {
                this.radioProtectionDisabled = value;
            }
        }

        public Label LabelDescProtection
        {
            get
            {
                return this.lblProtectionDesc;
            }
            set
            {
                this.lblProtectionDesc = value;
            }
        }

        public bool VizeProtectionEnabled
        {
            get
            {
                if (this.radioProtectionEnabled.Checked)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                if ((bool)value == true)
                {
                    this.radioProtectionEnabled.Checked = true;
                    this.radioProtectionDisabled.Checked = false;
                }
                else
                {
                    this.radioProtectionDisabled.Checked = true;
                    this.radioProtectionEnabled.Checked = false;
                }
            }
        }

        public bool VizeReloadNotifierEnabled
        {
            get
            {
                if (this.radioNotifierEnabled.Checked)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                if ((bool)value == true)
                {
                    this.radioNotifierEnabled.Checked = true;
                    this.radioNotifierDisabled.Checked = false;
                }
                else
                {
                    this.radioNotifierDisabled.Checked = true;
                    this.radioNotifierEnabled.Checked = false;
                }
            }
        }

        public VistaControls.Button ButtonApply
        {
            get
            {
                return this.btnApply;
            }
            set
            {
                btnApply = value;
            }
        }

        public Label LabelSettingsApplied
        {
            get
            {
                return this.lblSettingsApplied;
            }
            set
            {
                this.lblSettingsApplied = value;
            }
        }

        public Label GroupBoxVizeReloaderNotifier
        {
            get
            {
                return this.gbxReloadNotifier;
            }
            set
            {
                this.gbxReloadNotifier = value;
            }
        }

        public RadioButton RadioNotifierDisabled
        {
            get
            {
                return this.radioNotifierDisabled;
            }
            set
            {
                this.radioNotifierDisabled = value;
            }
        }

        public RadioButton RadioNotifierEnabled
        {
            get
            {
                return this.radioNotifierEnabled;
            }
            set
            {
                this.radioNotifierEnabled = value;
            }
        }

        public Label LabelNotifierDesc
        {
            get
            {
                return this.lblNotifierDesc;
            }
            set 
            {
                this.lblNotifierDesc = value;
            }
        }
    }
}