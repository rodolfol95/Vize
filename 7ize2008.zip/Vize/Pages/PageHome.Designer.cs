﻿namespace Vize.Pages
{
    partial class PageHome
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblChooseOption = new System.Windows.Forms.Label();
            this.btnReloaderPage = new Vize.VistaControls.CommandLink();
            this.btnRestorePage = new Vize.VistaControls.CommandLink();
            this.btnPatchPage = new Vize.VistaControls.CommandLink();
            this.lblDescHome = new System.Windows.Forms.Label();
            this.lblTitleHome = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lblChooseOption);
            this.panel1.Controls.Add(this.btnReloaderPage);
            this.panel1.Controls.Add(this.btnRestorePage);
            this.panel1.Controls.Add(this.btnPatchPage);
            this.panel1.Controls.Add(this.lblDescHome);
            this.panel1.Controls.Add(this.lblTitleHome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 440);
            this.panel1.TabIndex = 2;
            // 
            // lblChooseOption
            // 
            this.lblChooseOption.AutoSize = true;
            this.lblChooseOption.Location = new System.Drawing.Point(7, 95);
            this.lblChooseOption.Name = "lblChooseOption";
            this.lblChooseOption.Size = new System.Drawing.Size(209, 13);
            this.lblChooseOption.TabIndex = 2;
            this.lblChooseOption.Text = "Please choose a task below to proceed:";
            // 
            // btnReloaderPage
            // 
            this.btnReloaderPage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReloaderPage.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnReloaderPage.Location = new System.Drawing.Point(7, 221);
            this.btnReloaderPage.Margin = new System.Windows.Forms.Padding(3, 8, 3, 8);
            this.btnReloaderPage.Name = "btnReloaderPage";
            this.btnReloaderPage.Note = "This lets you reapply resources in files updated by Windows Update.";
            this.btnReloaderPage.Size = new System.Drawing.Size(480, 73);
            this.btnReloaderPage.TabIndex = 4;
            this.btnReloaderPage.Text = "Look for Files that Need Reloading";
            this.btnReloaderPage.UseVisualStyleBackColor = true;
            // 
            // btnRestorePage
            // 
            this.btnRestorePage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestorePage.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRestorePage.Location = new System.Drawing.Point(7, 308);
            this.btnRestorePage.Margin = new System.Windows.Forms.Padding(3, 8, 3, 8);
            this.btnRestorePage.Name = "btnRestorePage";
            this.btnRestorePage.Note = "This lets you restore original Windows files.";
            this.btnRestorePage.Size = new System.Drawing.Size(480, 73);
            this.btnRestorePage.TabIndex = 5;
            this.btnRestorePage.Text = "Restore System Files";
            this.btnRestorePage.UseVisualStyleBackColor = true;
            // 
            // btnPatchPage
            // 
            this.btnPatchPage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPatchPage.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPatchPage.Location = new System.Drawing.Point(7, 135);
            this.btnPatchPage.Margin = new System.Windows.Forms.Padding(3, 8, 3, 8);
            this.btnPatchPage.Name = "btnPatchPage";
            this.btnPatchPage.Note = "This lets you update resources in system files.";
            this.btnPatchPage.Size = new System.Drawing.Size(480, 73);
            this.btnPatchPage.TabIndex = 3;
            this.btnPatchPage.Text = "Patch System Files";
            this.btnPatchPage.UseVisualStyleBackColor = true;
            // 
            // lblDescHome
            // 
            this.lblDescHome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescHome.Location = new System.Drawing.Point(4, 40);
            this.lblDescHome.Name = "lblDescHome";
            this.lblDescHome.Size = new System.Drawing.Size(448, 38);
            this.lblDescHome.TabIndex = 1;
            this.lblDescHome.Text = "Vize lets you update resources in system files which contain non-Vista icons, ima" +
                "ges and animations.";
            // 
            // lblTitleHome
            // 
            this.lblTitleHome.AutoSize = true;
            this.lblTitleHome.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTitleHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.lblTitleHome.Location = new System.Drawing.Point(3, 3);
            this.lblTitleHome.Name = "lblTitleHome";
            this.lblTitleHome.Size = new System.Drawing.Size(85, 21);
            this.lblTitleHome.TabIndex = 0;
            this.lblTitleHome.Text = "Vize Home";
            // 
            // PageHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Name = "PageHome";
            this.Size = new System.Drawing.Size(500, 440);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblChooseOption;
        private VistaControls.CommandLink btnReloaderPage;
        private VistaControls.CommandLink btnRestorePage;
        private VistaControls.CommandLink btnPatchPage;
        private System.Windows.Forms.Label lblDescHome;
        private System.Windows.Forms.Label lblTitleHome;
    }
}
