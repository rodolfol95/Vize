﻿using System.ComponentModel;
using System.Windows.Forms;

namespace Vize.Pages
{
    public partial class PageReloader : UserControl
    {
        public PageReloader()
        {
            InitializeComponent();
        }

        public VistaControls.ComboBox ComboReloaderSelectFiles
        {
            get
            {
                return this.cmbSelect;
            }
            set
            {
                this.cmbSelect = value;
            }

        }

        public VistaControls.ListView ListReloadFiles
        {
            get
            {
                return this.lstReloadFiles;
            }
            set
            {
                this.lstReloadFiles = value;
            }

        }

        public VistaControls.ProgressBar ProgressBarReloader
        {
            get
            {
                return this.progressBarReloader;
            }
            set
            {
                this.progressBarReloader = value;
            }

        }

        public VistaControls.Button ButtonReloadCheck
        {
            get
            {
                return this.btnReload;
            }
            set
            {
                this.btnReload = value;
            }

        }

        public Label LabelStatusReload
        {
            get
            {
                return this.lblStatusReloader;
            }
            set
            {
                this.lblStatusReloader = value;
            }

        }

        public LinkLabel LabelSeeErrors
        {
            get
            {
                return this.linkSeeErrorsReloader;
            }
            set
            {
                this.linkSeeErrorsReloader = value;
            }

        }

        public PictureBox PicInfoReloader
        {
            get
            {
                return this.picInfoReloader;
            }
            set
            {
                this.picInfoReloader = value;
            }
        }

        public Label LabelDescReloader
        {
            get
            {
                return this.lblDescReloader;
            }
            set
            {
                this.lblDescReloader = value;
            }

        }
    }
}
