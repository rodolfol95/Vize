﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Vize.VistaControls;

namespace Vize.Pages
{
    public partial class PageAbout : UserControl
    {
        public PageAbout()
        {
            InitializeComponent();
        }

        public Label LabelTranslation
        {
            get
            {
                return this.lblTranslation;
            }
            set
            {
                this.lblTranslation = value;
            }
        }

        public Label LabelTitleAbout
        {
            get
            {
                return this.lblTitleAbout;
            }
            set
            {
                this.lblTitleAbout = value;
            }
        }

        public Label LabelDesc1About
        {
            get
            {
                return this.lblDescAbout1;
            }
            set
            {
                this.lblDescAbout1 = value;
            }
        }

        public Label LabelDesc2About
        {
            get
            {
                return this.lblDescAbout2;
            }
            set
            {
                this.lblDescAbout2 = value;
            }
        }

        public Label LabelDesc3About
        {
            get
            {
                return this.lblDescAbout3;
            }
            set
            {
                this.lblDescAbout3 = value;
            }
        }

        public CommandLink ButtonVisitHomepage
        {
            get
            {
                return this.btnVisitHomepage;
            }
            set
            {
                this.btnVisitHomepage = value;
            }

        }

        public Label LabelVersion
        {
            get
            {
                return this.lblVersion;
            }
            set 
            {
                this.lblVersion = value;
            }
        }

        public Label LabelTranslationAuthor
        {
            get
            {
                return this.lblTranslationAuthor;
            }
            set
            {
                this.lblTranslationAuthor = value;
            }
        }

        private void PageAbout_Load(object sender, EventArgs e)
        {

        }

        private void lblCopyRight_Click(object sender, EventArgs e)
        {

        }
    }
}
