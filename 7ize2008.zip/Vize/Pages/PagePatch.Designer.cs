﻿using Vize.VistaControls;

namespace Vize.Pages
{
    partial class PagePatch
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.linkSeeErrorsPatcher = new System.Windows.Forms.LinkLabel();
            this.lblStatusPatcher = new System.Windows.Forms.Label();
            this.picInfoPatcher = new System.Windows.Forms.PictureBox();
            this.btnPatch = new Vize.VistaControls.Button();
            this.progressBarPatcher = new Vize.VistaControls.ProgressBar();
            this.cmbSelect = new Vize.VistaControls.ComboBox();
            this.lstPatchFiles = new Vize.VistaControls.ListView();
            this.File = new System.Windows.Forms.ColumnHeader();
            this.Type = new System.Windows.Forms.ColumnHeader();
            this.ShipsWindows = new System.Windows.Forms.ColumnHeader();
            this.Path = new System.Windows.Forms.ColumnHeader();
            this.lblDescPatcher = new System.Windows.Forms.Label();
            this.lblTitlePatcher = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panelInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfoPatcher)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panelInfo);
            this.panel1.Controls.Add(this.btnPatch);
            this.panel1.Controls.Add(this.progressBarPatcher);
            this.panel1.Controls.Add(this.cmbSelect);
            this.panel1.Controls.Add(this.lstPatchFiles);
            this.panel1.Controls.Add(this.lblDescPatcher);
            this.panel1.Controls.Add(this.lblTitlePatcher);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 440);
            this.panel1.TabIndex = 3;
            // 
            // panelInfo
            // 
            this.panelInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(199)))));
            this.panelInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelInfo.Controls.Add(this.linkSeeErrorsPatcher);
            this.panelInfo.Controls.Add(this.lblStatusPatcher);
            this.panelInfo.Controls.Add(this.picInfoPatcher);
            this.panelInfo.Location = new System.Drawing.Point(11, 363);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(477, 22);
            this.panelInfo.TabIndex = 4;
            // 
            // linkSeeErrorsPatcher
            // 
            this.linkSeeErrorsPatcher.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.linkSeeErrorsPatcher.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkSeeErrorsPatcher.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkSeeErrorsPatcher.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.linkSeeErrorsPatcher.Location = new System.Drawing.Point(359, 4);
            this.linkSeeErrorsPatcher.Name = "linkSeeErrorsPatcher";
            this.linkSeeErrorsPatcher.Size = new System.Drawing.Size(113, 13);
            this.linkSeeErrorsPatcher.TabIndex = 1;
            this.linkSeeErrorsPatcher.TabStop = true;
            this.linkSeeErrorsPatcher.Text = "See errors";
            this.linkSeeErrorsPatcher.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkSeeErrorsPatcher.Visible = false;
            this.linkSeeErrorsPatcher.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            // 
            // lblStatusPatcher
            // 
            this.lblStatusPatcher.AutoSize = true;
            this.lblStatusPatcher.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblStatusPatcher.Location = new System.Drawing.Point(26, 4);
            this.lblStatusPatcher.Name = "lblStatusPatcher";
            this.lblStatusPatcher.Size = new System.Drawing.Size(223, 13);
            this.lblStatusPatcher.TabIndex = 0;
            this.lblStatusPatcher.Text = "Select which files to patch and click Patch.";
            // 
            // picInfoPatcher
            // 
            this.picInfoPatcher.Image = global::Vize.Properties.Resources.info;
            this.picInfoPatcher.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.picInfoPatcher.Location = new System.Drawing.Point(3, 2);
            this.picInfoPatcher.Name = "picInfoPatcher";
            this.picInfoPatcher.Size = new System.Drawing.Size(16, 16);
            this.picInfoPatcher.TabIndex = 0;
            this.picInfoPatcher.TabStop = false;
            // 
            // btnPatch
            // 
            this.btnPatch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPatch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPatch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPatch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnPatch.Location = new System.Drawing.Point(403, 412);
            this.btnPatch.Name = "btnPatch";
            this.btnPatch.Size = new System.Drawing.Size(85, 25);
            this.btnPatch.TabIndex = 6;
            this.btnPatch.Text = "Patch";
            this.btnPatch.UseVisualStyleBackColor = true;
            // 
            // progressBarPatcher
            // 
            this.progressBarPatcher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarPatcher.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.progressBarPatcher.Location = new System.Drawing.Point(11, 391);
            this.progressBarPatcher.Name = "progressBarPatcher";
            this.progressBarPatcher.Size = new System.Drawing.Size(477, 15);
            this.progressBarPatcher.TabIndex = 5;
            // 
            // cmbSelect
            // 
            this.cmbSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSelect.CueBannerText = "Select files";
            this.cmbSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelect.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbSelect.FormattingEnabled = true;
            this.cmbSelect.Items.AddRange(new object[] {
            "All",
            "All Dll",
            "All Exe",
            "All Cpl"});
            this.cmbSelect.Location = new System.Drawing.Point(346, 103);
            this.cmbSelect.Name = "cmbSelect";
            this.cmbSelect.Size = new System.Drawing.Size(142, 21);
            this.cmbSelect.TabIndex = 2;
            // 
            // lstPatchFiles
            // 
            this.lstPatchFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstPatchFiles.CheckBoxes = true;
            this.lstPatchFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.File,
            this.Type,
            this.ShipsWindows,
            this.Path});
            this.lstPatchFiles.FullRowSelect = true;
            this.lstPatchFiles.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstPatchFiles.Location = new System.Drawing.Point(11, 130);
            this.lstPatchFiles.Name = "lstPatchFiles";
            this.lstPatchFiles.Size = new System.Drawing.Size(477, 227);
            this.lstPatchFiles.TabIndex = 3;
            this.lstPatchFiles.UseCompatibleStateImageBehavior = false;
            this.lstPatchFiles.View = System.Windows.Forms.View.Details;
            // 
            // File
            // 
            this.File.Name = "File";
            this.File.Text = "File";
            this.File.Width = 170;
            // 
            // Type
            // 
            this.Type.Name = "Type";
            this.Type.Text = "Type";
            this.Type.Width = 50;
            // 
            // ShipsWindows
            // 
            this.ShipsWindows.Name = "ShipsWindows";
            this.ShipsWindows.Text = "Ships with Windows";
            this.ShipsWindows.Width = 130;
            // 
            // Path
            // 
            this.Path.Name = "Path";
            this.Path.Text = "Path";
            this.Path.Width = 300;
            // 
            // lblDescPatcher
            // 
            this.lblDescPatcher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescPatcher.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDescPatcher.Location = new System.Drawing.Point(4, 40);
            this.lblDescPatcher.Name = "lblDescPatcher";
            this.lblDescPatcher.Size = new System.Drawing.Size(484, 60);
            this.lblDescPatcher.TabIndex = 1;
            this.lblDescPatcher.Text = "Vize Patcher will update resources in system files which contains non-Vista icons" +
                ", images and animations. It will also make a backup of the original files in cas" +
                "e you need to restore them.";
            // 
            // lblTitlePatcher
            // 
            this.lblTitlePatcher.AutoSize = true;
            this.lblTitlePatcher.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTitlePatcher.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.lblTitlePatcher.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTitlePatcher.Location = new System.Drawing.Point(3, 3);
            this.lblTitlePatcher.Name = "lblTitlePatcher";
            this.lblTitlePatcher.Size = new System.Drawing.Size(95, 21);
            this.lblTitlePatcher.TabIndex = 0;
            this.lblTitlePatcher.Text = "Vize Patcher";
            // 
            // PagePatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Name = "PagePatch";
            this.Size = new System.Drawing.Size(500, 440);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfoPatcher)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDescPatcher;
        private System.Windows.Forms.Label lblTitlePatcher;
        private VistaControls.ComboBox cmbSelect;
        private VistaControls.ListView lstPatchFiles;
        //private System.Windows.Forms.ColumnHeader columnHeaderFile;
        //private System.Windows.Forms.ColumnHeader columnHeaderType;
        //private System.Windows.Forms.ColumnHeader columnHeaderShipWindows;
        private VistaControls.Button btnPatch;
        private VistaControls.ProgressBar progressBarPatcher;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.LinkLabel linkSeeErrorsPatcher;
        private System.Windows.Forms.Label lblStatusPatcher;
        private System.Windows.Forms.PictureBox picInfoPatcher;
        //private System.Windows.Forms.ColumnHeader columnHeaderPath;
        private System.Windows.Forms.ColumnHeader File;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader ShipsWindows;
        private System.Windows.Forms.ColumnHeader Path;
    }
}
