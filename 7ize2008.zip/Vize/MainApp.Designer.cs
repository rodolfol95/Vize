﻿using System.Xml;
using System.Reflection;
using System.IO;
namespace Vize
{
    partial class MainApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainApp));
            this.imageListFileType = new System.Windows.Forms.ImageList(this.components);
            this.imageListSummary = new System.Windows.Forms.ImageList(this.components);
            this.patcherWorker = new System.ComponentModel.BackgroundWorker();
            this.restorerWorker = new System.ComponentModel.BackgroundWorker();
            this.reloaderWorker = new System.ComponentModel.BackgroundWorker();
            this.panelLeft = new Vize.VistaControls.DBPanel();
            this.lblCheckUpdates = new System.Windows.Forms.Label();
            this.picCheckUpdates = new System.Windows.Forms.PictureBox();
            this.lblDotMisc = new System.Windows.Forms.Label();
            this.lblMisc = new System.Windows.Forms.Label();
            this.lblDotLinks = new System.Windows.Forms.Label();
            this.picAbout = new System.Windows.Forms.PictureBox();
            this.lblOptions = new System.Windows.Forms.Label();
            this.picOptions = new System.Windows.Forms.PictureBox();
            this.lblRestorer = new System.Windows.Forms.Label();
            this.picRestorer = new System.Windows.Forms.PictureBox();
            this.lblReloader = new System.Windows.Forms.Label();
            this.picReloader = new System.Windows.Forms.PictureBox();
            this.lblPatcher = new System.Windows.Forms.Label();
            this.picPatcher = new System.Windows.Forms.PictureBox();
            this.lblQuickLinks = new System.Windows.Forms.Label();
            this.lblAbout = new System.Windows.Forms.Label();
            this.lblTitleLeft = new System.Windows.Forms.Label();
            this.lblDotHome = new System.Windows.Forms.Label();
            this.panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCheckUpdates)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAbout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOptions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRestorer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picReloader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPatcher)).BeginInit();
            this.SuspendLayout();
            // 
            // imageListFileType
            // 
            this.imageListFileType.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListFileType.ImageStream")));
            this.imageListFileType.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListFileType.Images.SetKeyName(0, "dll.png");
            this.imageListFileType.Images.SetKeyName(1, "exe.png");
            this.imageListFileType.Images.SetKeyName(2, "cpl.png");
            // 
            // imageListSummary
            // 
            this.imageListSummary.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListSummary.ImageStream")));
            this.imageListSummary.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListSummary.Images.SetKeyName(0, "patched.png");
            // 
            // patcherWorker
            // 
            this.patcherWorker.WorkerSupportsCancellation = true;
            this.patcherWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.patcherWorkerDoWork);
            this.patcherWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.patcherWorkerRunWorkerCompleted);
            // 
            // restorerWorker
            // 
            this.restorerWorker.WorkerSupportsCancellation = true;
            this.restorerWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.restorerWorkerDoWork);
            this.restorerWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.restorerWorkerRunWorkerCompleted);
            // 
            // reloaderWorker
            // 
            this.reloaderWorker.WorkerSupportsCancellation = true;
            this.reloaderWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.reloaderWorkerDoWork);
            this.reloaderWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.reloaderWorkerRunWorkerCompleted);
            // 
            // panelLeft
            // 
            this.panelLeft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.panelLeft.BackColor = System.Drawing.SystemColors.Control;
            this.panelLeft.BackgroundImage = global::Vize.Properties.Resources.back;
            this.panelLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelLeft.Controls.Add(this.lblCheckUpdates);
            this.panelLeft.Controls.Add(this.picCheckUpdates);
            this.panelLeft.Controls.Add(this.lblDotMisc);
            this.panelLeft.Controls.Add(this.lblMisc);
            this.panelLeft.Controls.Add(this.lblDotLinks);
            this.panelLeft.Controls.Add(this.picAbout);
            this.panelLeft.Controls.Add(this.lblOptions);
            this.panelLeft.Controls.Add(this.picOptions);
            this.panelLeft.Controls.Add(this.lblRestorer);
            this.panelLeft.Controls.Add(this.picRestorer);
            this.panelLeft.Controls.Add(this.lblReloader);
            this.panelLeft.Controls.Add(this.picReloader);
            this.panelLeft.Controls.Add(this.lblPatcher);
            this.panelLeft.Controls.Add(this.picPatcher);
            this.panelLeft.Controls.Add(this.lblQuickLinks);
            this.panelLeft.Controls.Add(this.lblAbout);
            this.panelLeft.Controls.Add(this.lblTitleLeft);
            this.panelLeft.Controls.Add(this.lblDotHome);
            this.panelLeft.Location = new System.Drawing.Point(-2, -1);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(180, 461);
            this.panelLeft.TabIndex = 0;
            // 
            // lblCheckUpdates
            // 
            this.lblCheckUpdates.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblCheckUpdates.AutoSize = true;
            this.lblCheckUpdates.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckUpdates.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCheckUpdates.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckUpdates.ForeColor = System.Drawing.Color.White;
            this.lblCheckUpdates.Location = new System.Drawing.Point(37, 403);
            this.lblCheckUpdates.Name = "lblCheckUpdates";
            this.lblCheckUpdates.Size = new System.Drawing.Size(103, 15);
            this.lblCheckUpdates.TabIndex = 17;
            this.lblCheckUpdates.Text = "Check for updates";
            this.lblCheckUpdates.MouseLeave += new System.EventHandler(this.lblCheckUpdates_MouseLeave);
            this.lblCheckUpdates.Click += new System.EventHandler(this.lblCheckUpdatesClick);
            this.lblCheckUpdates.MouseHover += new System.EventHandler(this.lblCheckUpdates_MouseHover);
            // 
            // picCheckUpdates
            // 
            this.picCheckUpdates.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picCheckUpdates.BackColor = System.Drawing.Color.Transparent;
            this.picCheckUpdates.Image = global::Vize.Properties.Resources.updates;
            this.picCheckUpdates.Location = new System.Drawing.Point(10, 400);
            this.picCheckUpdates.Name = "picCheckUpdates";
            this.picCheckUpdates.Size = new System.Drawing.Size(20, 20);
            this.picCheckUpdates.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picCheckUpdates.TabIndex = 16;
            this.picCheckUpdates.TabStop = false;
            // 
            // lblDotMisc
            // 
            this.lblDotMisc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDotMisc.AutoSize = true;
            this.lblDotMisc.BackColor = System.Drawing.Color.Transparent;
            this.lblDotMisc.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.lblDotMisc.ForeColor = System.Drawing.Color.White;
            this.lblDotMisc.Location = new System.Drawing.Point(14, 333);
            this.lblDotMisc.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblDotMisc.Name = "lblDotMisc";
            this.lblDotMisc.Size = new System.Drawing.Size(16, 17);
            this.lblDotMisc.TabIndex = 15;
            this.lblDotMisc.Text = "●";
            this.lblDotMisc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDotMisc.Visible = false;
            // 
            // lblMisc
            // 
            this.lblMisc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMisc.AutoSize = true;
            this.lblMisc.BackColor = System.Drawing.Color.Transparent;
            this.lblMisc.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblMisc.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.lblMisc.ForeColor = System.Drawing.Color.White;
            this.lblMisc.Location = new System.Drawing.Point(36, 333);
            this.lblMisc.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblMisc.Name = "lblMisc";
            this.lblMisc.Size = new System.Drawing.Size(90, 17);
            this.lblMisc.TabIndex = 14;
            this.lblMisc.Text = "Miscellaneous";
            // 
            // lblDotLinks
            // 
            this.lblDotLinks.AutoSize = true;
            this.lblDotLinks.BackColor = System.Drawing.Color.Transparent;
            this.lblDotLinks.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.lblDotLinks.ForeColor = System.Drawing.Color.White;
            this.lblDotLinks.Location = new System.Drawing.Point(14, 71);
            this.lblDotLinks.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblDotLinks.Name = "lblDotLinks";
            this.lblDotLinks.Size = new System.Drawing.Size(16, 17);
            this.lblDotLinks.TabIndex = 13;
            this.lblDotLinks.Text = "●";
            this.lblDotLinks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDotLinks.Visible = false;
            // 
            // picAbout
            // 
            this.picAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picAbout.BackColor = System.Drawing.Color.Transparent;
            this.picAbout.Image = global::Vize.Properties.Resources.about;
            this.picAbout.Location = new System.Drawing.Point(10, 430);
            this.picAbout.Name = "picAbout";
            this.picAbout.Size = new System.Drawing.Size(20, 20);
            this.picAbout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picAbout.TabIndex = 12;
            this.picAbout.TabStop = false;
            // 
            // lblOptions
            // 
            this.lblOptions.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblOptions.AutoSize = true;
            this.lblOptions.BackColor = System.Drawing.Color.Transparent;
            this.lblOptions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOptions.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptions.ForeColor = System.Drawing.Color.White;
            this.lblOptions.Location = new System.Drawing.Point(37, 374);
            this.lblOptions.Name = "lblOptions";
            this.lblOptions.Size = new System.Drawing.Size(49, 15);
            this.lblOptions.TabIndex = 11;
            this.lblOptions.Text = "Options";
            this.lblOptions.MouseLeave += new System.EventHandler(this.lblOptions_MouseLeave);
            this.lblOptions.Click += new System.EventHandler(this.lblOptionsClick);
            this.lblOptions.MouseHover += new System.EventHandler(this.lblOptions_MouseHover);
            // 
            // picOptions
            // 
            this.picOptions.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picOptions.BackColor = System.Drawing.Color.Transparent;
            this.picOptions.Image = global::Vize.Properties.Resources.options;
            this.picOptions.Location = new System.Drawing.Point(10, 374);
            this.picOptions.Name = "picOptions";
            this.picOptions.Size = new System.Drawing.Size(20, 20);
            this.picOptions.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picOptions.TabIndex = 10;
            this.picOptions.TabStop = false;
            // 
            // lblRestorer
            // 
            this.lblRestorer.AutoSize = true;
            this.lblRestorer.BackColor = System.Drawing.Color.Transparent;
            this.lblRestorer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblRestorer.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestorer.ForeColor = System.Drawing.Color.White;
            this.lblRestorer.Location = new System.Drawing.Point(36, 170);
            this.lblRestorer.Name = "lblRestorer";
            this.lblRestorer.Size = new System.Drawing.Size(74, 15);
            this.lblRestorer.TabIndex = 9;
            this.lblRestorer.Text = "7ize Restorer";
            this.lblRestorer.MouseLeave += new System.EventHandler(this.lblRestorer_MouseLeave);
            this.lblRestorer.Click += new System.EventHandler(this.ButtonRestorePageClick);
            this.lblRestorer.MouseHover += new System.EventHandler(this.lblRestorer_MouseHover);
            // 
            // picRestorer
            // 
            this.picRestorer.BackColor = System.Drawing.Color.Transparent;
            this.picRestorer.Image = global::Vize.Properties.Resources.restorer;
            this.picRestorer.Location = new System.Drawing.Point(10, 168);
            this.picRestorer.Name = "picRestorer";
            this.picRestorer.Size = new System.Drawing.Size(20, 20);
            this.picRestorer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picRestorer.TabIndex = 8;
            this.picRestorer.TabStop = false;
            // 
            // lblReloader
            // 
            this.lblReloader.AutoSize = true;
            this.lblReloader.BackColor = System.Drawing.Color.Transparent;
            this.lblReloader.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblReloader.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReloader.ForeColor = System.Drawing.Color.White;
            this.lblReloader.Location = new System.Drawing.Point(36, 139);
            this.lblReloader.Name = "lblReloader";
            this.lblReloader.Size = new System.Drawing.Size(77, 15);
            this.lblReloader.TabIndex = 7;
            this.lblReloader.Text = "7ize Reloader";
            this.lblReloader.MouseLeave += new System.EventHandler(this.lblReloader_MouseLeave);
            this.lblReloader.Click += new System.EventHandler(this.ButtonReloadPageClick);
            this.lblReloader.MouseHover += new System.EventHandler(this.lblReloader_MouseHover);
            // 
            // picReloader
            // 
            this.picReloader.BackColor = System.Drawing.Color.Transparent;
            this.picReloader.Image = global::Vize.Properties.Resources.reloader;
            this.picReloader.Location = new System.Drawing.Point(10, 137);
            this.picReloader.Name = "picReloader";
            this.picReloader.Size = new System.Drawing.Size(20, 20);
            this.picReloader.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picReloader.TabIndex = 6;
            this.picReloader.TabStop = false;
            // 
            // lblPatcher
            // 
            this.lblPatcher.AutoSize = true;
            this.lblPatcher.BackColor = System.Drawing.Color.Transparent;
            this.lblPatcher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPatcher.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatcher.ForeColor = System.Drawing.Color.White;
            this.lblPatcher.Location = new System.Drawing.Point(36, 109);
            this.lblPatcher.Name = "lblPatcher";
            this.lblPatcher.Size = new System.Drawing.Size(71, 15);
            this.lblPatcher.TabIndex = 5;
            this.lblPatcher.Text = "7ize Patcher";
            this.lblPatcher.MouseLeave += new System.EventHandler(this.lblPatcher_MouseLeave);
            this.lblPatcher.Click += new System.EventHandler(this.ButtonPatchPageClick);
            this.lblPatcher.MouseHover += new System.EventHandler(this.lblPatcher_MouseHover);
            // 
            // picPatcher
            // 
            this.picPatcher.BackColor = System.Drawing.Color.Transparent;
            this.picPatcher.Image = global::Vize.Properties.Resources.patcher;
            this.picPatcher.Location = new System.Drawing.Point(10, 107);
            this.picPatcher.Name = "picPatcher";
            this.picPatcher.Size = new System.Drawing.Size(20, 20);
            this.picPatcher.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picPatcher.TabIndex = 4;
            this.picPatcher.TabStop = false;
            // 
            // lblQuickLinks
            // 
            this.lblQuickLinks.AutoSize = true;
            this.lblQuickLinks.BackColor = System.Drawing.Color.Transparent;
            this.lblQuickLinks.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblQuickLinks.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.lblQuickLinks.ForeColor = System.Drawing.Color.White;
            this.lblQuickLinks.Location = new System.Drawing.Point(36, 71);
            this.lblQuickLinks.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblQuickLinks.Name = "lblQuickLinks";
            this.lblQuickLinks.Size = new System.Drawing.Size(72, 17);
            this.lblQuickLinks.TabIndex = 3;
            this.lblQuickLinks.Text = "Quick Links";
            // 
            // lblAbout
            // 
            this.lblAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblAbout.AutoSize = true;
            this.lblAbout.BackColor = System.Drawing.Color.Transparent;
            this.lblAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAbout.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAbout.ForeColor = System.Drawing.Color.White;
            this.lblAbout.Location = new System.Drawing.Point(36, 432);
            this.lblAbout.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(40, 15);
            this.lblAbout.TabIndex = 2;
            this.lblAbout.Text = "About";
            this.lblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAbout.MouseLeave += new System.EventHandler(this.lblAbout_MouseLeave);
            this.lblAbout.Click += new System.EventHandler(this.lblAboutClick);
            this.lblAbout.MouseHover += new System.EventHandler(this.lblAbout_MouseHover);
            // 
            // lblTitleLeft
            // 
            this.lblTitleLeft.AutoSize = true;
            this.lblTitleLeft.BackColor = System.Drawing.Color.Transparent;
            this.lblTitleLeft.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblTitleLeft.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.lblTitleLeft.ForeColor = System.Drawing.Color.White;
            this.lblTitleLeft.Location = new System.Drawing.Point(36, 16);
            this.lblTitleLeft.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblTitleLeft.Name = "lblTitleLeft";
            this.lblTitleLeft.Size = new System.Drawing.Size(71, 17);
            this.lblTitleLeft.TabIndex = 1;
            this.lblTitleLeft.Text = "7ize Home";
            this.lblTitleLeft.MouseLeave += new System.EventHandler(this.lblTitleLeft_MouseLeave);
            this.lblTitleLeft.Click += new System.EventHandler(this.lblTitleLeftClick);
            this.lblTitleLeft.MouseHover += new System.EventHandler(this.lblTitleLeft_MouseHover);
            // 
            // lblDotHome
            // 
            this.lblDotHome.AutoSize = true;
            this.lblDotHome.BackColor = System.Drawing.Color.Transparent;
            this.lblDotHome.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.lblDotHome.ForeColor = System.Drawing.Color.White;
            this.lblDotHome.Location = new System.Drawing.Point(14, 15);
            this.lblDotHome.Margin = new System.Windows.Forms.Padding(3, 14, 3, 14);
            this.lblDotHome.Name = "lblDotHome";
            this.lblDotHome.Size = new System.Drawing.Size(16, 17);
            this.lblDotHome.TabIndex = 0;
            this.lblDotHome.Text = "●";
            this.lblDotHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MainApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(692, 461);
            this.Controls.Add(this.panelLeft);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(700, 493);
            this.Name = "MainApp";
            this.Text = "7ize";
            this.Load += new System.EventHandler(this.MainAppLoad);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainAppFormClosing);
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCheckUpdates)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAbout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOptions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRestorer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picReloader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPatcher)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        VistaControls.DBPanel panelLeft;
        private System.Windows.Forms.ImageList imageListFileType;
        private System.Windows.Forms.Label lblDotHome;
        private System.Windows.Forms.Label lblTitleLeft;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.ImageList imageListSummary;
        private Vize.Pages.PageHome pageHome1;
        private Vize.Pages.PagePatch pagePatch1;
        private Vize.Pages.PageReloader pageReloader1;
        private Vize.Pages.PageRestore pageRestore1;
        private Vize.Pages.PageAbout pageAbout1;
        private Vize.Pages.PageOptions pageOptions1;
        private System.ComponentModel.BackgroundWorker patcherWorker;
        private System.ComponentModel.BackgroundWorker restorerWorker;
        private System.ComponentModel.BackgroundWorker reloaderWorker;
        private System.Windows.Forms.Label lblQuickLinks;
        private System.Windows.Forms.PictureBox picPatcher;
        private System.Windows.Forms.Label lblPatcher;
        private System.Windows.Forms.Label lblRestorer;
        private System.Windows.Forms.PictureBox picRestorer;
        private System.Windows.Forms.Label lblReloader;
        private System.Windows.Forms.PictureBox picReloader;
        private System.Windows.Forms.Label lblOptions;
        private System.Windows.Forms.PictureBox picOptions;
        private System.Windows.Forms.PictureBox picAbout;
        private System.Windows.Forms.Label lblDotLinks;
        private System.Windows.Forms.Label lblDotMisc;
        private System.Windows.Forms.Label lblMisc;
        private System.Windows.Forms.Label lblCheckUpdates;
        private System.Windows.Forms.PictureBox picCheckUpdates;
    }
}

